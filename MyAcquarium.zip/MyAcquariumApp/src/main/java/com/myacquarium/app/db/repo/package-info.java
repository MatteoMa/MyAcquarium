/** Fornisce interfacce per le operazioni CRUD generiche sui repository. */
package com.myacquarium.app.db.repo;