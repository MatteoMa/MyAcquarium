/** Fornisce classi persistenti delle entita' rappresentanti gli oggetti della base dati. */
package com.myacquarium.app.db;