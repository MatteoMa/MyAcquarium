package com.myacquarium.app.db;

import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.app.db.sc.Device;

/**
 * Classe persistente dell'entita' TesterSiO4 rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class TesterSiO4 extends Device {
	
	/** L'acquario che possiede il tester. */
	@OneToOne(mappedBy = "testerSiO4")
    private Acquarium acquarium;
	
	/**
	 * Metodo per ottenere l'acquario che possiede il tester.
	 * @return l'acquario che possiede il tester
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario che possiede il tester.
	 * @param acquarium l'acquario che possiede il tester
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
