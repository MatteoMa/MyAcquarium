package com.myacquarium.app.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.app.db.DatiSensoriRicevuti;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo DatiSensoriRicevuti
 * che sara' implementata automaticamente da Spring in un Bean chiamato datiSensoriRicevutiRepository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface DatiSensoriRicevutiRepository extends CrudRepository<DatiSensoriRicevuti, UUID> {}
