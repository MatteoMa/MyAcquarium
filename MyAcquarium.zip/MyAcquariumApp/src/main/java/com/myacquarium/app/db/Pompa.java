package com.myacquarium.app.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.app.db.sc.Device;

/**
 * Classe persistente dell'entita' Pompa rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class Pompa extends Device {
	
	/** Stato della pompa (ON acceso, OFF spento). */
	@Column(columnDefinition = "varchar(255) default 'OFF'")
	private String status = "OFF";
	
	/** L'acquario che possiede la pompa. */
	@OneToOne(mappedBy = "pompa")
    private Acquarium acquarium;
	
	/**
	 * Metodo per ottenere lo stato della pompa.
	 * @return lo stato della pompa
	 */
	public String getStatus() { return status; }
	/**
	 * Metodo per impostare lo stato della pompa.
	 * @param status lo stato della pompa
	 */
	public void setStatus(String status) { this.status = status; }
	
	/**
	 * Metodo per ottenere l'acquario che possiede la pompa.
	 * @return l'acquario che possiede la pompa
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario che possiede la pompa.
	 * @param acquarium l'acquario che possiede la pompa
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
