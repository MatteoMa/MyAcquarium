package com.myacquarium.app.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.app.db.sc.Device;

/**
 * Classe persistente dell'entita' FiltroSiO4 rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class FiltroSiO4 extends Device {
	
	/** Stato del filtro (ON acceso, OFF spento). */
	@Column(columnDefinition = "varchar(255) default 'OFF'")
	private String status = "OFF";
	
	/** L'acquario che possiede il filtro. */
	@OneToOne(mappedBy = "filtroSiO4")
    private Acquarium acquarium;
	
	/**
	 * Metodo per ottenere lo stato del filtro.
	 * @return lo stato del filtro
	 */
	public String getStatus() { return status; }
	/**
	 * Metodo per impostare lo stato del filtro.
	 * @param status lo stato del filtro
	 */
	public void setStatus(String status) { this.status = status; }
	
	/**
	 * Metodo per ottenere l'acquario che possiede il filtro.
	 * @return l'acquario che possiede il filtro
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario che possiede il filtro.
	 * @param acquarium l'acquario che possiede il filtro
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
