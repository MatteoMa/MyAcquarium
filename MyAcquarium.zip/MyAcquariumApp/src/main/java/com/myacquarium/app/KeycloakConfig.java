package com.myacquarium.app;

import org.keycloak.adapters.springboot.KeycloakSpringBootConfigResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Classe per generare la richiesta di servizio di configurazione di Keycloak.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
@Configuration
public class KeycloakConfig {

	/**
	 * Metodo per istanziare la classe KeycloakSpringBootConfigResolver.
	 * @return istanza della classe KeycloakSpringBootConfigResolver
	 */
    @Bean
    public KeycloakSpringBootConfigResolver keycloakConfigResolver() {
        return new KeycloakSpringBootConfigResolver();
    }
}
