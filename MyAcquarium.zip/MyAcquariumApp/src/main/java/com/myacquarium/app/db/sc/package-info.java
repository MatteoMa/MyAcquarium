/** Fornisce classi astratte le cui informazioni di mappatura sono applicate alle entita' che ereditano da essa. */
package com.myacquarium.app.db.sc;