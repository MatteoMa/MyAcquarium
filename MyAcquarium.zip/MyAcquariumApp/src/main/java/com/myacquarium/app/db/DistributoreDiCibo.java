package com.myacquarium.app.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.app.db.sc.Device;

/**
 * Classe persistente dell'entita' DistributoreDiCibo rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class DistributoreDiCibo extends Device {
	
	/** Data e ora dell'ultima attivazione del distributore di cibo: indica l'ultimo pasto dato ai pesci. */
	@Column
	private java.time.LocalDateTime lastMeal = java.time.LocalDateTime.now();

	/** Quantita' di cibo in percentuale contenuto nel distributore di cibo (0 vuoto, 100 pieno). */
	@Column(columnDefinition = "integer default 100")
	private Integer quantity = 100;
	
	/** L'acquario che possiede il distributore di cibo. */
	@OneToOne(mappedBy = "distributoreDiCibo")
    private Acquarium acquarium;
	
	/**
	 * Metodo per ottenere la data e l'ora dell'ultima attivazione del distributore di cibo.
	 * @return data e ora dell'ultima attivazione del distributore di cibo
	 */
	public java.time.LocalDateTime getLastMeal() { return lastMeal; }
	/**
	 * Metodo per impostare la data e l'ora dell'ultima attivazione del distributore di cibo.
	 * @param lastMeal data e ora dell'ultima attivazione del distributore di cibo
	 */
	public void setLastMeal(java.time.LocalDateTime lastMeal) { this.lastMeal = lastMeal; }
	
	/**
	 * Metodo per ottenere la quantita' di cibo in percentuale contenuto nel distributore di cibo.
	 * @return data e ora dell'ultima attivazione del distributore di cibo
	 */
	public Integer getQuantity() { return quantity; }
	/**
	 * Metodo per impostare la quantita' di cibo in percentuale contenuto nel distributore di cibo.
	 * @param quantity la quantita' di cibo in percentuale contenuto nel distributore di cibo
	 */
	public void setQuantity(Integer quantity) { this.quantity = quantity; }
	
	/**
	 * Metodo per ottenere l'acquario che possiede il distributore di cibo.
	 * @return l'acquario che possiede il distributore di cibo
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario che possiede il distributore di cibo.
	 * @param acquarium l'acquario che possiede il distributore di cibo
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
