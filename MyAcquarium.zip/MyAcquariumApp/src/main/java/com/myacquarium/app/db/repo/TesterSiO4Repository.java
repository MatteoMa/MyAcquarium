package com.myacquarium.app.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.app.db.TesterSiO4;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo TesterSiO4
 * che sara' implementata automaticamente da Spring in un Bean chiamato TesterSiO4Repository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface TesterSiO4Repository extends CrudRepository<TesterSiO4, UUID> {}
