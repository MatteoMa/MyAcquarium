package com.myacquarium.app.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.app.db.FiltroNO3;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo FiltroNO3
 * che sara' implementata automaticamente da Spring in un Bean chiamato filtroNO3Repository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface FiltroNO3Repository extends CrudRepository<FiltroNO3, UUID> {}
