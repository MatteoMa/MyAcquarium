package com.myacquarium.app;

import org.keycloak.adapters.springboot.KeycloakSpringBootConfigResolver;
import org.keycloak.adapters.springsecurity.KeycloakConfiguration;
import org.keycloak.adapters.springsecurity.authentication.KeycloakAuthenticationProvider;
import org.keycloak.adapters.springsecurity.config.KeycloakWebSecurityConfigurerAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.authority.mapping.SimpleAuthorityMapper;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;

/**
 * Classe utilizzata per eseguire il bootstrap e lanciare l'applicazione Spring dal metodo main di Java.
 * Sono presenti metodi di Spring Security e di Keycloak per l'autenticazione e l'autorizzazione dell'applicazione.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@SpringBootApplication
public class MyAcquariumApplication {

	/**
	 * Metodo principale per il lancio dell'applicazione Spring.
	 * @param args argomenti passati come parametro all'applicazione
	 */
	public static void main(String[] args) {
		SpringApplication.run(MyAcquariumApplication.class, args);
	}

}

/**
 * Classe per la configurazione di Spring Security con metodi personalizzati per l'utilizzo di Keycloak.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
@KeycloakConfiguration
class SecurityConfig extends KeycloakWebSecurityConfigurerAdapter {

	/**
	 * Metodo di configurazione di Spring Security.
	 * 
	 * @param auth
	 * @throws Exception
	 */
    @Autowired
    public void configureGlobal(
      AuthenticationManagerBuilder auth) throws Exception {
 
        KeycloakAuthenticationProvider keycloakAuthenticationProvider
          = keycloakAuthenticationProvider();
        keycloakAuthenticationProvider.setGrantedAuthoritiesMapper(
          new SimpleAuthorityMapper());
        auth.authenticationProvider(keycloakAuthenticationProvider);
    }

    @Bean
    @Override
    protected SessionAuthenticationStrategy sessionAuthenticationStrategy() {
        return new RegisterSessionAuthenticationStrategy(
          new SessionRegistryImpl());
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        super.configure(http);
        http.authorizeRequests()
          .antMatchers("/user/**").hasRole("user")
          .antMatchers("/acquariums/**").hasRole("user")
          .antMatchers("/warnings/**").hasRole("user")
          .antMatchers("/fishes/**").hasRole("user")
          .anyRequest()
          .permitAll();
    }
}

/**
 * Classe per generare la richiesta di servizio di configurazione di Keycloak.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
@Configuration
class KeycloakConfig {

	/**
	 * Metodo per istanziare la classe KeycloakSpringBootConfigResolver.
	 * @return istanza della classe KeycloakSpringBootConfigResolver
	 */
    @Bean
    public KeycloakSpringBootConfigResolver keycloakConfigResolver() {
        return new KeycloakSpringBootConfigResolver();
    }
}
