package com.myacquarium.app;

import java.security.Principal;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.keycloak.representations.AccessToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.myacquarium.app.db.Acquarium;
import com.myacquarium.app.db.Avviso;
import com.myacquarium.app.db.DatiSensoriRicevuti;
import com.myacquarium.app.db.MonitoraggioRicevuto;
import com.myacquarium.app.db.RegoleDiControllo;
import com.myacquarium.app.db.repo.AcquariumRepository;
import com.myacquarium.app.db.repo.AvvisoRepository;

/**
 * Classe controller responsabile dell'elaborazione delle richieste API REST in arrivo,
 * della preparazione di un modello e della restituzione della vista da rendere come risposta.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Controller
public class MyController {
	
	/** Autowired delle classe AcquariumRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private AcquariumRepository acquariumRepository;
	
	/** Autowired delle classe AvvisoRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private AvvisoRepository avvisoRepository;
	
	/**
	 * Metodo per gestire la richiesta HTTP GET al path "/" ritornando la pagina principale.
	 * @param principal entita' astratta dell'utente autenticato
	 * @return la pagina "index.html"
	 */
	@GetMapping(path = "/")
	public String index(Principal principal) {
	    return "index";
	}

	/**
	 * Metodo per gestire la richiesta HTTP GET al path "/user" ritornando la pagina configurata delle informazioni dell'utente.
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return la pagina "user.html"
	 */
	@GetMapping(path = "/user")
	public String user(Model model, Principal principal) {
		KeycloakAuthenticationToken keycloakAuthenticationToken = (KeycloakAuthenticationToken) principal;
	    AccessToken accessToken = keycloakAuthenticationToken.getAccount().getKeycloakSecurityContext().getToken();
	    model.addAttribute("firstName", accessToken.getGivenName());
	    model.addAttribute("lastName", accessToken.getFamilyName());
	    model.addAttribute("email", accessToken.getEmail());
	    if (acquariumRepository.findByUtente(principal.getName()).isEmpty()) model.addAttribute("haveAcquarium", false);
	    else model.addAttribute("haveAcquarium", true);
	    return "user";
	}
	
	/**
	 * Metodo per rimuovere l'utente autenticato quando viene effettuata una richiesta HTTP GET al path "/logout"
	 * reindirizzandolo successivamente alla pagina principale.
	 * @param request
	 * @return reindirizzamento alla pagina principale "index.html"
	 * @throws ServletException
	 */
	@GetMapping(path = "/logout")
	public String logout(HttpServletRequest request) throws ServletException {
		request.logout();
		return "redirect:/";
	   }
	
	/**
	 * Metodo per gestire la richiesta HTTP GET al path "/acquariums" ritornando la pagina configurata degli acquari dell'utente.
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return la pagina "acquariums.html"
	 */
	@GetMapping(path = "/acquariums")
	public String acquariums(Model model, Principal principal) {
		KeycloakAuthenticationToken keycloakAuthenticationToken = (KeycloakAuthenticationToken) principal;
	    AccessToken accessToken = keycloakAuthenticationToken.getAccount().getKeycloakSecurityContext().getToken();
	    model.addAttribute("firstName", accessToken.getGivenName());
	    model.addAttribute("lastName", accessToken.getFamilyName());
		List<Acquarium> acquariums = acquariumRepository.findByUtente(principal.getName());
		model.addAttribute("acquariums", acquariums);
		if (acquariums.isEmpty()) model.addAttribute("haveAcquarium", false);
	    else model.addAttribute("haveAcquarium", true);
	    return "acquariums";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP GET al path "/acquariums/{id}"
	 * ritornando la pagina configurata dell'acquario che corrisponde al parametro "id" della richiesta.
	 * In caso di errore, viene ritornata la pagina "error.html".
	 * @param id variabile dell'URI designante l'UUID dell'acquario
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return la pagina "acquariumInfo.html"
	 */
	@GetMapping(path = "/acquariums/{id}")
	public String acquariumInfo(@PathVariable UUID id, Model model, Principal principal) {
		Acquarium acquarium = acquariumRepository.findById(id).orElse(null);
		if (acquarium == null || !acquarium.getUtente().equals(principal.getName())) return "error";
		model.addAttribute("acquarium", acquarium);
	    return "acquariumInfo";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP GET al path "/acquariums/new" ritornando la pagina configurata di creazione dell'acquario.
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return la pagina "newOrEditAcquarium.html"
	 */
	@GetMapping(path = "/acquariums/new")
	public String showNewAcquariumForm(Model model, Principal principal) {
		model.addAttribute("acquariumForm", new AcquariumForm());
		model.addAttribute("editMode", false);
	    return "newOrEditAcquarium";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP POST di creazione di un nuovo acquario al path "/acquariums/new"
	 * reindirizzando successivamente l'utente alla pagina degli acquari posseduti.
	 * @param acquariumForm attributo del modello per legare i parametri del form di creazione dell'acquario
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return reindirizzamento alla pagina degli acquari dell'utente
	 */
	@PostMapping("/acquariums/new")
	public String doNewAcquarium(@ModelAttribute AcquariumForm acquariumForm, Model model, Principal principal) {
		Acquarium acquarium = new Acquarium();
		acquarium.acquariumFormation(acquariumForm);
		acquarium.setUtente(principal.getName());
		RegoleDiControllo rules = new RegoleDiControllo();
		if (acquarium.getTipo().equals("dolce")) rules.setDefaultDolce();
		else rules.setDefaultMarino();
		acquarium.setRegoleDiControllo(rules);
		acquarium.setDatiSensoriRicevuti(new DatiSensoriRicevuti());
		acquarium.setMonitoraggioRicevuto(new MonitoraggioRicevuto());
		acquariumRepository.save(acquarium);
	    return "redirect:/acquariums";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP GET al path "/acquariums/{id}/editDevices"
	 * ritornando la pagina configurata di modifica dell'acquario che corrisponde al parametro "id" della richiesta.
	 * In caso di errore, viene ritornata la pagina "error.html".
	 * @param id variabile dell'URI designante l'UUID dell'acquario
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return la pagina "newOrEditAcquarium.html"
	 */
	@GetMapping(path = "/acquariums/{id}/editDevices")
	public String showEditAcquariumForm(@PathVariable UUID id, Model model, Principal principal) {
		Acquarium acquarium = acquariumRepository.findById(id).orElse(null);
		if (acquarium == null || !acquarium.getUtente().equals(principal.getName())) return "error";
		AcquariumForm aF = new AcquariumForm();
		aF.invarify();
		aF.setNome(acquarium.getNome());
		aF.setTipo(acquarium.getTipo());
		aF.setPesci(acquarium.getPesci());
		model.addAttribute("acquariumForm", aF);
		model.addAttribute("editMode", true);
		return "newOrEditAcquarium";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP PUT di modifica dell'acquario al path "/acquariums/{id}/editDevices"
	 * reindirizzando successivamente l'utente alla pagina degli acquari posseduti.
	 * In caso di errore, viene ritornata la pagina "error.html".
	 * @param acquariumForm attributo del modello per legare i parametri del form di modifica dell'acquario
	 * @param id variabile dell'URI designante l'UUID dell'acquario
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return reindirizzamento alla pagina degli acquari dell'utente
	 */
	@PutMapping("/acquariums/{id}/editDevices")
	public String doUpdateAcquarium(@ModelAttribute AcquariumForm acquariumForm, @PathVariable UUID id, Model model, Principal principal) {
		Acquarium acquarium = acquariumRepository.findById(id).orElse(null);
		if (acquarium == null || !acquarium.getUtente().equals(principal.getName())) return "error";
		acquarium.acquariumFormation(acquariumForm);
		acquariumRepository.save(acquarium);
	    return "redirect:/acquariums";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP GET al path "/acquariums/{id}/editRules"
	 * ritornando la pagina configurata di modifica delle regole di gestione dell'acquario che corrisponde al parametro "id" della richiesta.
	 * In caso di errore, viene ritornata la pagina "error.html".
	 * @param id variabile dell'URI designante l'UUID dell'acquario
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return la pagina "editRules.html"
	 */
	@GetMapping(path = "/acquariums/{id}/editRules")
	public String showEditRulesForm(@PathVariable UUID id, Model model, Principal principal) {
		Acquarium acquarium = acquariumRepository.findById(id).orElse(null);
		if (acquarium == null || !acquarium.getUtente().equals(principal.getName())) return "error";
		String type = acquarium.getTipo();
		String name = acquarium.getNome();
		model.addAttribute("rules", acquarium.getRegoleDiControllo());
		model.addAttribute("type", type);
		model.addAttribute("name", name);
		return "editRules";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP PUT di modifica delle regole di gestione dell'acquario al path "/acquariums/{id}/editRules"
	 * reindirizzando successivamente l'utente alla pagina degli acquari posseduti.
	 * In caso di errore, viene ritornata la pagina "error.html".
	 * @param rules attributo del modello per legare i parametri del form di modifica delle regole di gestione dell'acquario
	 * @param id variabile dell'URI designante l'UUID dell'acquario
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return reindirizzamento alla pagina degli acquari dell'utente
	 */
	@PutMapping("/acquariums/{id}/editRules")
	public String doUpdateRules(@ModelAttribute RegoleDiControllo rules, @PathVariable UUID id, Model model, Principal principal) {
		Acquarium acquarium = acquariumRepository.findById(id).orElse(null);
		if (acquarium == null || !acquarium.getUtente().equals(principal.getName())) return "error";
		acquarium.setRegoleDiControllo(rules);
		acquariumRepository.save(acquarium);
	    return "redirect:/acquariums";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP DELETE di eliminazione di un acquario al path "/acquariums/{id}"
	 * reindirizzando successivamente l'utente alla pagina degli acquari posseduti.
	 * In caso di errore, viene ritornata la pagina "error.html".
	 * @param id variabile dell'URI designante l'UUID dell'acquario
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return reindirizzamento alla pagina degli acquari dell'utente
	 */
	@DeleteMapping("/acquariums/{id}")
	public String deleteAcquarium(@PathVariable UUID id, Model model, Principal principal) {
		Acquarium acquarium = acquariumRepository.findById(id).orElse(null);
		if (acquarium == null || !acquarium.getUtente().equals(principal.getName())) return "error";
		acquariumRepository.deleteById(id);
		return "redirect:/acquariums";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP DELETE di eliminazione di un avviso al path "/warnings/{id}"
	 * reindirizzando successivamente l'utente alla pagina degli avvisi.
	 * In caso di errore, viene ritornata la pagina "error.html".
	 * @param id variabile dell'URI designante l'UUID dell'avviso
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return reindirizzamento alla pagina degli avvisi dell'utente
	 */
	@DeleteMapping("/warnings/{id}")
	public String deleteWarning(@PathVariable UUID id, Model model, Principal principal) {
		Avviso avviso = avvisoRepository.findById(id).orElse(null);
		if (avviso == null || !avviso.getAcquarium().getUtente().equals(principal.getName())) return "error";
		avviso.getAcquarium().removeAvviso(avviso);
		avvisoRepository.deleteById(id);
		return "redirect:/warnings";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP GET al path "/fishes" ritornando la pagina delle tipologie di pesci adatte per i vari tipi di acquario.
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return la pagina "fishes.html"
	 */
	@GetMapping("/fishes")
	public String fishes(Model model, Principal principal) {
	    return "fishes";
	}
	
	/**
	 * Metodo per gestire la richiesta HTTP GET al path "/warnings" ritornando la pagina degli avvisi segnalati dai dispositivi degli acquari dell'utente.
	 * @param model interfaccia di supporto per gli attributi del modello
	 * @param principal entita' astratta dell'utente autenticato
	 * @return la pagina "warnings.html"
	 */
	@GetMapping("/warnings")
	public String warnings(Model model, Principal principal) {
		List<Acquarium> acquariums = acquariumRepository.findByUtente(principal.getName());
		model.addAttribute("acquariums", acquariums);
		if (acquariums.isEmpty()) model.addAttribute("haveAcquarium", false);
	    else model.addAttribute("haveAcquarium", true);
	    return "warnings";
	}
	
}
