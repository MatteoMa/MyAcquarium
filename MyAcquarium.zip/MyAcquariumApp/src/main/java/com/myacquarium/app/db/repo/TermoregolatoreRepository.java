package com.myacquarium.app.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.app.db.Termoregolatore;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo Termoregolatore
 * che sara' implementata automaticamente da Spring in un Bean chiamato termoregolatoreRepository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface TermoregolatoreRepository extends CrudRepository<Termoregolatore, UUID> {}
