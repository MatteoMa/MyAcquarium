package com.myacquarium.app.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.app.db.Schiumatoio;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo Schiumatoio
 * che sara' implementata automaticamente da Spring in un Bean chiamato schiumatoioRepository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface SchiumatoioRepository extends CrudRepository<Schiumatoio, UUID> {}
