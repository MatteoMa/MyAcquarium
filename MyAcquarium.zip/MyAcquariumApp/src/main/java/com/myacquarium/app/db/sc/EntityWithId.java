package com.myacquarium.app.db.sc;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * Classe designata MappedSuperclass le cui informazioni di mappatura sono applicate alle entita' che ereditano da essa
 * (non esiste una tabella di mappatura per questa classe).
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@MappedSuperclass
public abstract class EntityWithId {

	/** Chiave primaria dell'entita' di tipo UUID. */
    @Id
    @GeneratedValue
    @Column(columnDefinition = "BINARY(16)")
    private UUID id;

    /**
	 * Metodo per ottenere la chiave primaria dell'entita'.
	 * @return la chiave primaria dell'entita'
	 */
	public UUID getId() { return id; }
	
}
