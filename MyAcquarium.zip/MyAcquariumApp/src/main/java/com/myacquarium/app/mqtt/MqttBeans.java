package com.myacquarium.app.mqtt;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMDecryptorProvider;
import org.bouncycastle.openssl.PEMEncryptedKeyPair;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.openssl.jcajce.JcePEMDecryptorProviderBuilder;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.core.MessageProducer;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.integration.mqtt.inbound.MqttPahoMessageDrivenChannelAdapter;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.integration.mqtt.support.DefaultPahoMessageConverter;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessagingException;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.myacquarium.app.db.Acquarium;
import com.myacquarium.app.db.repo.AcquariumRepository;
import com.myacquarium.app.db.repo.MonitoraggioRicevutoRepository;
import com.myacquarium.app.db.MonitoraggioRicevuto;

/**
 * Classe per la configurazione di adattori di canali in entrata e in uscita per il supporto del protocollo MQTT.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Configuration
public class MqttBeans {
	
	/** Topic MQTT di sottoscrizione per la ricezione di messaggi. */
	private static final String SUBTOPIC = "myacquarium/+/app/#";
	
	/** Autowired delle classe AcquariumRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private AcquariumRepository acquariumRepository;
	
	/** Autowired delle classe MonitoraggioRicevutoRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private MonitoraggioRicevutoRepository monitoraggioRicevutoRepository;
	
	/**
	 * Metodo per la creazione di un Client MQTT configurando i suo parametri per la corretta connessione al server.
	 * L'username non e' necessario in quanto viene usato il nome comune (CN) del certificato come username per il controllo degli accessi,
	 * e la password non viene utilizzata perche' si presume che solo i client autenticati abbiano certificati validi.
	 * @return il Client MQTT configurato
	 */
    @Bean
    public MqttPahoClientFactory mqttClientFactory() {
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        MqttConnectOptions options = new MqttConnectOptions();
        options.setServerURIs(new String[] {"ssl://localhost:8883"});
        options.setCleanSession(true);
        options.setConnectionTimeout(30);
        options.setKeepAliveInterval(60);
        options.setAutomaticReconnect(true);
        try {
        	InputStream inCaCrtFile = getClass().getResourceAsStream("/certificates/MQTT_ca.crt");
        	InputStream inCrtFile = getClass().getResourceAsStream("/certificates/MQTT_app.crt");
        	InputStream inKeyFile = getClass().getResourceAsStream("/certificates/MQTT_app.key");
        	SSLSocketFactory socketFactory = getSocketFactory(inCaCrtFile, inCrtFile, inKeyFile, "");
			options.setSocketFactory(socketFactory);
		} catch (Exception e) {
	    		e.printStackTrace();
	    }
        factory.setConnectionOptions(options);
        return factory;
    }
    
    /**
     * Metodo per la creazione di Socket SSL.
     * @param inCaCrtFile flusso di byte in ingresso del certificato dell'Autorita' Certificativa in formato CRT
     * @param inCrtFile flusso di byte in ingresso del certificato del client in formato CRT inviato al server per l'autenticazione
     * @param inKeyFile flusso di byte in ingresso della chiave privata del client in formato KEY
     * @param password password per decriptare la chiave privata del client (se necessaria)
     * @return il Socket SSL creato
     * @throws Exception
     */
    private static SSLSocketFactory getSocketFactory(final InputStream inCaCrtFile, final InputStream inCrtFile, final InputStream inKeyFile, final String password) throws Exception {
	    Security.addProvider(new BouncyCastleProvider());
	    X509Certificate caCert = null;
	
	    BufferedInputStream bis = new BufferedInputStream(inCaCrtFile);
	    CertificateFactory cf = CertificateFactory.getInstance("X.509");
	
	    while (bis.available() > 0) {
	            caCert = (X509Certificate) cf.generateCertificate(bis);
	    }
	
	    bis = new BufferedInputStream(inCrtFile);
	    X509Certificate cert = null;
	    while (bis.available() > 0) {
	            cert = (X509Certificate) cf.generateCertificate(bis);
	    }
	    
	    Reader rKeyFile = new InputStreamReader(inKeyFile);
	    PEMParser pemParser = new PEMParser(rKeyFile);
	    Object object = pemParser.readObject();
	    PEMDecryptorProvider decProv = new JcePEMDecryptorProviderBuilder().build(password.toCharArray());
	    JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");
	    KeyPair key;
	    if (object instanceof PEMEncryptedKeyPair) {
	    	key = converter.getKeyPair(((PEMEncryptedKeyPair) object).decryptKeyPair(decProv));
	    }
	    else {
	    	key = converter.getKeyPair((PEMKeyPair) object);
	    }
	    pemParser.close();
	
	    KeyStore caKs = KeyStore.getInstance(KeyStore.getDefaultType());
	    caKs.load(null, null);
	    caKs.setCertificateEntry("ca-certificate", caCert);
	    TrustManagerFactory tmf = TrustManagerFactory.getInstance("X509");
	    tmf.init(caKs);
	
	    KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
	    ks.load(null, null);
	    ks.setCertificateEntry("certificate", cert);
	    ks.setKeyEntry("private-key", key.getPrivate(), password.toCharArray(), new java.security.cert.Certificate[] { cert });
	    KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
	    kmf.init(ks, password.toCharArray());
	
	    SSLContext context = SSLContext.getInstance("TLSv1.2");
	    context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
	
	    return context.getSocketFactory();
	}
	
	/**
	 * Metodo per definire i criteri per l'invio di messaggi.
	 * @return canale con la strategia predefinita RoundRobinLoadBalancingStrategy
	 */
	@Bean
    public MessageChannel mqttInputChannel() {
        return new DirectChannel();
    }

	/**
	 * Metodo per costruire l'interfaccia di base per l'invio di messaggi.
	 * @return l'interfaccia di base per l'invio di messaggi
	 */
    @Bean
    public MessageProducer inbound() {
    	String clientId = "uuid-" + UUID.randomUUID().toString();
        MqttPahoMessageDrivenChannelAdapter adapter = new MqttPahoMessageDrivenChannelAdapter(clientId, mqttClientFactory(), SUBTOPIC);
        adapter.setCompletionTimeout(20000);
        adapter.setConverter(new DefaultPahoMessageConverter());
        adapter.setQos(2);
        adapter.setOutputChannel(mqttInputChannel());
        return adapter;
    }

    /**
     * Metodo in grado di gestire messaggi MQTT in arrivo sul canale specificato dal ServiceActivator.
     * @return semplice contratto per la gestione di un messaggio
     */
    @Bean
    @ServiceActivator(inputChannel = "mqttInputChannel")
    public MessageHandler handler() {
        return new MessageHandler() {

            @Override
            public void handleMessage(Message<?> message) throws MessagingException {
            	String topic = message.getHeaders().get(MqttHeaders.RECEIVED_TOPIC).toString();
            	JsonObject jsonMessage = new Gson().fromJson(message.getPayload().toString(), JsonObject.class);
            	String[] topics = topic.split("/");
            	String mitt = ""; UUID acquariumId = UUID.randomUUID();
            	if (topics.length == 4) {
            		mitt = topics[3]; acquariumId = UUID.fromString(topics[1]);
            	}
            	if (mitt.equals("monitoring")) {
            		JsonElement jsonValue = jsonMessage.get("value");
            		JsonElement jsonData = jsonMessage.get("data");
            		if (jsonValue != null && jsonData != null) {
            			Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            			if (acquarium != null) {
            				String value = jsonValue.getAsString();
            				String data = jsonData.getAsString();
            				String data1 = data.replaceAll("[\\[\\]]", "");
            				String dataF[] = data1.split(",");
            				Float[] floats = Arrays.stream(dataF).map(Float::valueOf).toArray(Float[]::new);
            				List<Float> insert = new ArrayList<Float>(Arrays.asList(floats));
            				MonitoraggioRicevuto monitoraggio = acquarium.getMonitoraggioRicevuto();
            				if (value.equals("temperature")) monitoraggio.setTemperature(insert);
            				if (value.equals("waterLevel")) monitoraggio.setWaterLevel(insert);
            				if (value.equals("ca")) monitoraggio.setCa(insert);
            				if (value.equals("co2")) monitoraggio.setCo2(insert);
            				if (value.equals("ph")) monitoraggio.setPh(insert);
            				if (value.equals("no3")) monitoraggio.setNo3(insert);
            				if (value.equals("po4")) monitoraggio.setPo4(insert);
            				if (value.equals("sio4")) monitoraggio.setSio4(insert);
            				monitoraggioRicevutoRepository.save(monitoraggio);
            			}
            		}
            	}
            }
            
        };
    }

	/**
	 * Metodo per definire i criteri per l'invio di messaggi.
	 * @return canale con la strategia predefinita RoundRobinLoadBalancingStrategy
	 */
    @Bean
    public MessageChannel mqttOutboundChannel() {
        return new DirectChannel();
    }
    
	/**
	 * Metodo per costruire l'interfaccia di base per la gestione dei messaggi.
	 * @return l'interfaccia di base per la gestione dei messaggi
	 */
    @Bean
    @ServiceActivator(inputChannel = "mqttOutboundChannel")
    public MessageHandler mqttOutbound() {
    	String clientId = "uuid-" + UUID.randomUUID().toString();
        MqttPahoMessageHandler messageHandler = new MqttPahoMessageHandler(clientId, mqttClientFactory());
        messageHandler.setAsync(true);
        messageHandler.setDefaultTopic("#");
        return messageHandler;
    }

}
