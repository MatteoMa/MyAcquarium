package com.myacquarium.app;

/**
 * Classe di supporto per convertire i dati del form di creazione o modifica dell'acquario nell'effettiva classe dell'entita' Acquario.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 * 
 */

public class AcquariumForm {

	/** Il nome dell'acquario (obbligatorio). */
	private String nome = "";
	
	/** Le varie tipologie di pesci nell'acquario (facoltativo). */
	private String pesci = "";

	/** Il tipo di acquario (dolce/marino, obbligatorio). */
	private String tipo = "";
	
	// --------------------------------------------------------------------------

	/** Nome in codice del distributore di cibo (DDC100/DDC200, obbligatorio). */
	private String ddcCodename = "";
	
	/** Nome in codice del dispositivo di illuminazione (LED120/LED500/LED850, obbligatorio). */
	private String illCodename = "";
	
	/** Nome in codice della pompa (P1000/P3000/P5000, obbligatorio). */
	private String pCodename = "";
	
	/** Nome in codice del termoregolatore (SRR111/SRR222, facoltativo). */
	private String termCodename = "";
	
	// --------------------------------------------------------------------------
	
	/** Nome in codice del regolatore di livello (RDL10/RDL20, facoltativo). */
	private String rdlCodename = "";
	
	/** Nome in codice del tester di calcio (T001CA, facoltativo). */
	private String tCaCodename = "";
	
	/** Nome in codice del tester di anidride carbonica (T001CO2, facoltativo). */
	private String tCO2Codename = "";
	
	/** Nome in codice del tester di pH (T001PH, facoltativo). */
	private String tpHCodename = "";
	
	/** Nome in codice del tester di nitrati (T001NO3, facoltativo). */
	private String tNO3Codename = "";
	
	/** Nome in codice del tester di fosfati (T001PO4, facoltativo). */
	private String tPO4Codename = "";
	
	/** Nome in codice del tester di silicati (T001SI04, facoltativo). */
	private String tSiO4Codename = "";
	
	// --------------------------------------------------------------------------
	
	/** Nome in codice del regolatore di calcio (RDC1, facoltativo, disponibile in presenza di un tester di calcio). */
	private String rdcCodename = "";
	
	/** Nome in codice dell'impianto di anidride carbonica (ICO2, facoltativo, disponibile in presenza di un tester di anidride carbonica). */
	private String iCO2Codename = "";
	
	/** Nome in codice del filtro di nitrati (F001NO3, facoltativo, disponibile in presenza di un tester di nitrati). */
	private String fNO3Codename = "";
	
	/** Nome in codice del filtro di fosfati (F001PO4, facoltativo, disponibile in presenza di un tester di fosfati). */
	private String fPO4Codename = "";
	
	/** Nome in codice del filtro di silicati (F001SIO4, facoltativo, disponibile in presenza di un tester di silicati). */
	private String fSiO4Codename = "";
	
	// --------------------------------------------------------------------------
	
	/** Nome in codice dello schiumatoio per la purificazione dell'acqua da composti nocivi (SKI1, facoltativo). */
	private String schCodename = "";
	
	/** Nome in codice del reattore ad alghe per la purificazione dell'acqua da composti nocivi (RAA1, facoltativo). */
	private String raaCodename = "";
	
	// --------------------------------------------------------------------------
	
	/**
	 * Metodo per ottenere il nome dell'acquario.
	 * @return il nome dell'acquario
	 */
	public String getNome() { return nome; }
	/**
	 * Metodo per impostare il nome dell'acquario, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param nome il nome dell'acquario
	 */
	public void setNome(String nome) { this.nome = nome; }
	
	/**
	 * Metodo per ottenere le varie tipologie di pesci nell'acquario.
	 * @return stringa rappresentante le varie tipologie di pesci nell'acquario
	 */
	public String getPesci() { return pesci; }
	/**
	 * Metodo per impostare le varie tipologie di pesci nell'acquario, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param pesci stringa rappresentante le varie tipologie di pesci nell'acquario
	 */
	public void setPesci(String pesci) { this.pesci = pesci; }
	
	/**
	 * Metodo per ottenere il tipo di acquario.
	 * @return il tipo di acquario
	 */
	public String getTipo() { return tipo; }
	/**
	 * Metodo per impostare il tipo di acquario, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param tipo il tipo di acquario (dolce/marino)
	 */
	public void setTipo(String tipo) { this.tipo = tipo; }
	
	/**
	 * Metodo per ottenere il codice del distributore di cibo.
	 * @return il codice del distributore di cibo
	 */
	public String getDdcCodename() { return ddcCodename; }
	/**
	 * Metodo per impostare il codice del distributore di cibo, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param ddcCodename il codice del distributore di cibo
	 */
	public void setDdcCodename(String ddcCodename) { this.ddcCodename = ddcCodename; }
	
	/**
	 * Metodo per ottenere il codice del dispositivo di illuminazione.
	 * @return il codice del dispositivo di illuminazione
	 */
	public String getIllCodename() { return illCodename; }
	/**
	 * Metodo per impostare il codice del dispositivo di illuminazione, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param illCodename il codice del dispositivo di illuminazione
	 */
	public void setIllCodename(String illCodename) { this.illCodename = illCodename; }
	
	/**
	 * Metodo per ottenere il codice della pompa.
	 * @return il codice della pompa
	 */
	public String getPCodename() { return pCodename; }
	/**
	 * Metodo per impostare il codice della pompa, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param pCodename il codice della pompa
	 */
	public void setPCodename(String pCodename) { this.pCodename = pCodename; }
	
	/**
	 * Metodo per ottenere il codice del termoregolatore.
	 * @return il codice del termoregolatore
	 */
	public String getTermCodename() { return termCodename; }
	/**
	 * Metodo per impostare il codice del termoregolatore, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param termCodename il codice del termoregolatore
	 */
	public void setTermCodename(String termCodename) { this.termCodename = termCodename; }
	
	/**
	 * Metodo per ottenere il codice del regolatore di livello.
	 * @return il codice del regolatore di livello
	 */
	public String getRdlCodename() { return rdlCodename; }
	/**
	 * Metodo per impostare il codice del regolatore di livello, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param rdlCodename il codice del regolatore di livello
	 */
	public void setRdlCodename(String rdlCodename) { this.rdlCodename = rdlCodename; }
	
	/**
	 * Metodo per ottenere il codice del tester di calcio.
	 * @return il codice del tester di calcio
	 */
	public String getTCaCodename() { return tCaCodename; }
	/**
	 * Metodo per impostare il codice del tester di calcio, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param tCaCodename il codice del tester di calcio
	 */
	public void setTCaCodename(String tCaCodename) { this.tCaCodename = tCaCodename; }
	
	/**
	 * Metodo per ottenere il codice del tester di anidride carbonica.
	 * @return il codice del tester di anidride carbonica
	 */
	public String getTCO2Codename() { return tCO2Codename; }
	/**
	 * Metodo per impostare il codice del tester di anidride carbonica, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param tCO2Codename il codice del tester di anidride carbonica
	 */
	public void setTCO2Codename(String tCO2Codename) { this.tCO2Codename = tCO2Codename; }
	
	/**
	 * Metodo per ottenere il codice del tester di pH.
	 * @return il codice del tester di pH
	 */
	public String getTpHCodename() { return tpHCodename; }
	/**
	 * Metodo per impostare il codice del tester di pH, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param tpHCodename il codice del tester di pH
	 */
	public void setTpHCodename(String tpHCodename) { this.tpHCodename = tpHCodename; }
	
	/**
	 * Metodo per ottenere il codice del tester di nitrati.
	 * @return il codice del tester di nitrati
	 */
	public String getTNO3Codename() { return tNO3Codename; }
	/**
	 * Metodo per impostare il codice del tester di nitrati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param tNO3Codename il codice del tester di nitrati
	 */
	public void setTNO3Codename(String tNO3Codename) { this.tNO3Codename = tNO3Codename; }
	
	/**
	 * Metodo per ottenere il codice del tester di fosfati.
	 * @return il codice del tester di fosfati
	 */
	public String getTPO4Codename() { return tPO4Codename; }
	/**
	 * Metodo per impostare il codice del tester di fosfati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param tPO4Codename il codice del tester di fosfati
	 */
	public void setTPO4Codename(String tPO4Codename) { this.tPO4Codename = tPO4Codename; }
	
	/**
	 * Metodo per ottenere il codice del tester di silicati.
	 * @return il codice del tester di silicati
	 */
	public String getTSiO4Codename() { return tSiO4Codename; }
	/**
	 * Metodo per impostare il codice del tester di silicati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param tSiO4Codename il codice del tester di silicati
	 */
	public void setTSiO4Codename(String tSiO4Codename) { this.tSiO4Codename = tSiO4Codename; }
	
	/**
	 * Metodo per ottenere il codice del regolatore di calcio.
	 * @return il codice del regolatore di calcio
	 */
	public String getRdcCodename() { return rdcCodename; }
	/**
	 * Metodo per impostare il codice del regolatore di calcio, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param rdcCodename il codice del regolatore di calcio
	 */
	public void setRdcCodename(String rdcCodename) { this.rdcCodename = rdcCodename; }
	
	/**
	 * Metodo per ottenere il codice dell'impianto di anidride carbonica.
	 * @return il codice dell'impianto di anidride carbonica
	 */
	public String getICO2Codename() { return iCO2Codename; }
	/**
	 * Metodo per impostare il codice dell'impianto di anidride carbonica, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param iCO2Codename il codice dell'impianto di anidride carbonica
	 */
	public void setICO2Codename(String iCO2Codename) { this.iCO2Codename = iCO2Codename; }
	
	/**
	 * Metodo per ottenere il codice del filtro di nitrati.
	 * @return il codice del filtro di nitrati
	 */
	public String getFNO3Codename() { return fNO3Codename; }
	/**
	 * Metodo per impostare il codice del filtro di nitrati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param fNO3Codename il codice del filtro di nitrati
	 */
	public void setFNO3Codename(String fNO3Codename) { this.fNO3Codename = fNO3Codename; }
	
	/**
	 * Metodo per ottenere il codice del filtro di fosfati.
	 * @return il codice del filtro di fosfati
	 */
	public String getFPO4Codename() { return fPO4Codename; }
	/**
	 * Metodo per impostare il codice del filtro di fosfati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param fPO4Codename il codice del filtro di fosfati
	 */
	public void setFPO4Codename(String fPO4Codename) { this.fPO4Codename = fPO4Codename; }
	
	/**
	 * Metodo per ottenere il codice del filtro di silicati.
	 * @return il codice del filtro di silicati
	 */
	public String getFSiO4Codename() { return fSiO4Codename; }
	/**
	 * Metodo per impostare il codice del filtro di silicati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param fSiO4Codename il codice del filtro di silicati
	 */
	public void setFSiO4Codename(String fSiO4Codename) { this.fSiO4Codename = fSiO4Codename; }
	
	/**
	 * Metodo per ottenere il codice dello schiumatoio.
	 * @return il codice dello schiumatoio
	 */
	public String getSchCodename() { return schCodename; }
	/**
	 * Metodo per impostare il codice dello schiumatoio, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param schCodename il codice dello schiumatoio
	 */
	public void setSchCodename(String schCodename) { this.schCodename = schCodename; }
	
	/**
	 * Metodo per ottenere il codice del reattore ad alghe.
	 * @return il codice del reattore ad alghe
	 */
	public String getRaaCodename() { return raaCodename; }
	/**
	 * Metodo per impostare il codice del reattore ad alghe, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param raaCodename il codice del reattore ad alghe
	 */
	public void setRaaCodename(String raaCodename) { this.raaCodename = raaCodename; }
	
	/** Metodo per impostare a "invariato" ogni dispositivo prima di indicare le modifiche all'acquario effettuate. */
	public void invarify() {
		ddcCodename = "inv";
		illCodename = "inv";
		pCodename = "inv";
		termCodename = "inv";
		rdlCodename = "inv";
		tCaCodename = "inv";
		tCO2Codename = "inv";
		tpHCodename = "inv";
		tNO3Codename = "inv";
		tPO4Codename = "inv";
		tSiO4Codename = "inv";
		rdcCodename = "inv";
		iCO2Codename = "inv";
		fNO3Codename = "inv";
		fPO4Codename = "inv";
		fSiO4Codename = "inv";
		schCodename = "inv";
		raaCodename  = "inv";
	}

}
