/** Fornisce classi necessarie per il lancio dell'applicazione Spring e per gestire le richieste API REST. */
package com.myacquarium.app;