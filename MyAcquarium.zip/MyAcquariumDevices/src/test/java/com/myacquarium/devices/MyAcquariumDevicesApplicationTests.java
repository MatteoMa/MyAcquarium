package com.myacquarium.devices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyAcquariumDevicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
