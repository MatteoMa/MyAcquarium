package com.myacquarium.devices.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.devices.db.sc.Device;

/**
 * Classe persistente dell'entita' Schiumatoio rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class Schiumatoio extends Device {
	
	/** Stato dello schiumatoio (ON acceso, OFF spento). */
	@Column(columnDefinition = "varchar(255) default 'OFF'")
	private String status = "OFF";
	
	/** L'acquario che possiede lo schiumatoio. */
	@OneToOne(mappedBy = "schiumatoio")
    private Acquarium acquarium;
	
	/**
	 * Metodo per ottenere lo stato dello schiumatoio.
	 * @return lo stato dello schiumatoio
	 */
	public String getStatus() { return status; }
	/**
	 * Metodo per impostare lo stato dello schiumatoio.
	 * @param status lo stato dello schiumatoio
	 */
	public void setStatus(String status) { this.status = status; }
	
	/**
	 * Metodo per ottenere l'acquario che possiede lo schiumatoio.
	 * @return l'acquario che possiede lo schiumatoio
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario che possiede lo schiumatoio.
	 * @param acquarium l'acquario che possiede lo schiumatoio
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
