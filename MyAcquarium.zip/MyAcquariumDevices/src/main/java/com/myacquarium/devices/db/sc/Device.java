package com.myacquarium.devices.db.sc;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

/**
 * Classe designata MappedSuperclass le cui informazioni di mappatura sono applicate alle entita' che ereditano da essa
 * (non esiste una tabella di mappatura per questa classe).
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@MappedSuperclass
public abstract class Device extends EntityWithId {

	/** Nome in codice del dispositivo (obbligatorio). */
	@Column
	@NotNull
	private String codename;
	
	/** Data e ora di installazione del dispositivo. */
	@Column
	@NotNull
	private java.time.LocalDateTime data = java.time.LocalDateTime.now();

	/**
	 * Metodo per ottenere il nome in codice del dispositivo.
	 * @return il nome in codice del dispositivo
	 */
	public String getCodename() { return codename; }
	/**
	 * Metodo per impostare il nome in codice del dispositivo.
	 * @param codename il nome in codice del dispositivo
	 */
	public void setCodename(String codename) { this.codename = codename; }

	/**
	 * Metodo per ottenere la data e l'ora di installazione del dispositivo.
	 * @return data e ora di installazione del dispositivo
	 */
	public java.time.LocalDateTime getData() { return data; }
	/**
	 * Metodo per impostare la data e l'ora di installazione del dispositivo.
	 * @param data data e ora di installazione del dispositivo
	 */
	public void setData(java.time.LocalDateTime data) { this.data = data; }
	
}
