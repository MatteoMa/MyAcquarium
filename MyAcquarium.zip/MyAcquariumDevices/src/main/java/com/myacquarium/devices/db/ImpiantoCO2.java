package com.myacquarium.devices.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.devices.db.sc.Device;

/**
 * Classe persistente dell'entita' ImpiantoCO2 rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class ImpiantoCO2 extends Device {
	
	/** Stato dell'impianto di anidride carbonica (ON acceso, OFF spento). */
	@Column(columnDefinition = "varchar(255) default 'OFF'")
	private String status = "OFF";
	
	/** L'acquario che possiede l'impianto di anidride carbonica. */
	@OneToOne(mappedBy = "impiantoCO2")
    private Acquarium acquarium;
	
	/**
	 * Metodo per ottenere lo stato dell'impianto di anidride carbonica.
	 * @return lo stato dell'impianto di anidride carbonica
	 */
	public String getStatus() { return status; }
	/**
	 * Metodo per impostare lo stato dell'impianto di anidride carbonica.
	 * @param status lo stato dell'impianto di anidride carbonica
	 */
	public void setStatus(String status) { this.status = status; }
	
	/**
	 * Metodo per ottenere l'acquario che possiede l'impianto di anidride carbonica.
	 * @return l'acquario che possiede l'impianto di anidride carbonica
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario che possiede l'impianto di anidride carbonica.
	 * @param acquarium l'acquario che possiede l'impianto di anidride carbonica
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
