package com.myacquarium.devices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.google.gson.JsonObject;
import com.myacquarium.devices.db.Acquarium;
import com.myacquarium.devices.db.repo.AcquariumRepository;

/**
 * Classe per l'invio di messaggi MQTT programmati.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
@EnableScheduling
@Component
public class MqttSender {
	
	/** Autowired delle classe MyGateway per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private MyGateway myGateway;
	
	/** Autowired delle classe AcquariumRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private AcquariumRepository acquariumRepository;
	
	/** Prima parte del topic MQTT di inoltro. */
	private static final String T1 = "myacquarium/";
	/** Seconda parte del topic MQTT di inoltro (il destinatario). */
	private static final String T2 = "/agent/";

	/** Metodo programmato per l'inoltro di messaggi MQTT dai device all'agente ogni minuto. */
	@Scheduled(fixedRate = 60000)
    public void sendSensorDataToAgentEveryMinute() {
		Iterable <Acquarium> acquariums = acquariumRepository.findAll();
		for (Acquarium a : acquariums) {
			if (a.getDistributoreDiCibo() != null) distributoreDiCiboMessage(a);
			if (a.getIlluminazione() != null) illuminazioneMessage(a);
			if (a.getPompa() != null) pompaMessage(a);
			if (a.getTermoregolatore() != null) termoregolatoreMessage(a);
			if (a.getRegolatoreDiLivello() != null) regolatoreDiLivelloMessage(a);
			if (a.getTesterCa() != null) testerCaMessage(a);
			if (a.getTesterCO2() != null) testerCO2Message(a);
			if (a.getTesterpH() != null) testerpHMessage(a);
			if (a.getTesterNO3() != null) testerNO3Message(a);
			if (a.getTesterPO4() != null) testerPO4Message(a);
			if (a.getTesterSiO4() != null) testerSiO4Message(a);
			if (a.getReattoreDiCalcio() != null) reattoreDiCalcioMessage(a);
			if (a.getImpiantoCO2() != null) impiantoCO2Message(a);
			if (a.getFiltroNO3() != null) filtroNO3Message(a);
			if (a.getFiltroPO4() != null) filtroPO4Message(a);
			if (a.getFiltroSiO4() != null) filtroSiO4Message(a);
			if (a.getSchiumatoio() != null) schiumatoioMessage(a);
			if (a.getReattoreAdAlghe() != null) reattoreAdAlgheMessage(a);
		}
    }
    
	/**
	 * Metodo per la creazione del messaggio proveniente dal distributore di cibo.
	 * Contiene la data e l'ora dell'ultimo pasto e la quantita' di cibo in percentuale rimanente.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il distributore di cibo
	 */
	private void distributoreDiCiboMessage(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getDistributoreDiCibo().getId() + "&" + a.getDistributoreDiCibo().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("lastMeal", a.getDistributoreDiCibo().getLastMeal().toString());
		data.addProperty("quantity", a.getDistributoreDiCibo().getQuantity());
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal dispositivo di illuminazione.
	 * Contiene lo stato del dispositivo.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void illuminazioneMessage(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getIlluminazione().getId() + "&" + a.getIlluminazione().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getIlluminazione().getStatus());
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dalla pompa.
	 * Contiene lo stato del dispositivo.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void pompaMessage(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getPompa().getId() + "&" + a.getPompa().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getPompa().getStatus());
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}

	/**
	 * Metodo per la creazione del messaggio proveniente dal termoregolatore.
	 * Contiene lo stato del dispositivo e il valore di temperatura.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void termoregolatoreMessage(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getTermoregolatore().getId() + "&" + a.getTermoregolatore().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getTermoregolatore().getStatus());
		float temperature = 0;
		if (a.getTipo().equals("dolce")) temperature = (float)(Math.random()*(27-17+1)+17); // Da 17 a 27 gradi
		else temperature = (float)Math.random()*(29-22+1)+22; // Da 22 a 29 gradi
		data.addProperty("temperature", temperature);
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}

	/**
	 * Metodo per la creazione del messaggio proveniente dal regolatore di livello.
	 * Contiene lo stato del dispositivo e il valore di livello dell'acqua.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void regolatoreDiLivelloMessage(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getRegolatoreDiLivello().getId() + "&" + a.getRegolatoreDiLivello().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getRegolatoreDiLivello().getStatus());
		data.addProperty("waterLevel", (float)(Math.random()*(99-95+1)+95)); // Da 95 a 99 %
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal tester di calcio.
	 * Contiene lo stato del dispositivo e il valore di calcio.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void testerCaMessage(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getTesterCa().getId() + "&" + a.getTesterCa().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("ca", (float)(Math.random()*(470-380+1)+380)); // Da 380 a 470 mg/l
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal tester di anidride carbonica.
	 * Contiene lo stato del dispositivo e il valore di anidride carbonica.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void testerCO2Message(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getTesterCO2().getId() + "&" + a.getTesterCO2().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("co2", (float)(Math.random()*(43-17+1)+17)); // Da 17 a 43 mg/l
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal tester di pH.
	 * Contiene lo stato del dispositivo e il valore di pH.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void testerpHMessage(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getTesterpH().getId() + "&" + a.getTesterpH().getCodename();
		JsonObject data = new JsonObject();
		float ph = 0;
		if (a.getTipo().equals("dolce")) ph = (float)((Math.random()*(75-65+1)+65)/10); // Da 6,5 a 7,5 (dolce)
		else ph = (float)((Math.random()*(87-77+1)+77)/10); // Da 7,7 a 8,7 (marino)
		data.addProperty("ph", ph);
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal tester di nitrati.
	 * Contiene lo stato del dispositivo e il valore di nitrati.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void testerNO3Message(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getTesterNO3().getId() + "&" + a.getTesterNO3().getCodename();
		JsonObject data = new JsonObject();
		float no3 = 0;
		if (a.getTipo().equals("dolce")) no3 = (float)(Math.random()*(70-40+1)+40); // Da 40 a 70 mg/l (dolce)
		else no3 = (float)(Math.random()*(35-5+1)+5); // Da 5 a 35 mg/l (marino)
		data.addProperty("no3", no3);
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal tester di fosfati.
	 * Contiene lo stato del dispositivo e il valore di fosfati.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void testerPO4Message(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getTesterPO4().getId() + "&" + a.getTesterPO4().getCodename();
		JsonObject data = new JsonObject();
		float po4 = 0;
		if (a.getTipo().equals("dolce")) po4 = (float)((Math.random()*(4-0+1)+0)/100); // Da 0 a 0,04 mg/l (dolce)
		else po4 = (float)((Math.random()*(12-0+1)+0)/100); // Da 0 a 0,12 mg/l (marino)
		data.addProperty("po4", po4);
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal tester di silicati.
	 * Contiene lo stato del dispositivo e il valore di silicati.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void testerSiO4Message(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getTesterSiO4().getId() + "&" + a.getTesterSiO4().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("sio4", (float)((Math.random()*(5-0+1)+0)/10)); // Da 0 a 0,5 mg/l
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal reattore di calcio.
	 * Contiene lo stato del dispositivo.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void reattoreDiCalcioMessage(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getReattoreDiCalcio().getId() + "&" + a.getReattoreDiCalcio().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getReattoreDiCalcio().getStatus());
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dall'impianto di anidride carbonica.
	 * Contiene lo stato del dispositivo.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void impiantoCO2Message(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getImpiantoCO2().getId() + "&" + a.getImpiantoCO2().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getImpiantoCO2().getStatus());
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal filtro di nitrati.
	 * Contiene lo stato del dispositivo.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void filtroNO3Message(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getFiltroNO3().getId() + "&" + a.getFiltroNO3().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getFiltroNO3().getStatus());
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal filtro di fosfati.
	 * Contiene lo stato del dispositivo.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void filtroPO4Message(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getFiltroPO4().getId() + "&" + a.getFiltroPO4().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getFiltroPO4().getStatus());
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal filtro di silicati.
	 * Contiene lo stato del dispositivo.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void filtroSiO4Message(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getFiltroSiO4().getId() + "&" + a.getFiltroSiO4().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getFiltroSiO4().getStatus());
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dallo schiumatoio.
	 * Contiene lo stato del dispositivo.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void schiumatoioMessage(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getSchiumatoio().getId() + "&" + a.getSchiumatoio().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getSchiumatoio().getStatus());
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 * Metodo per la creazione del messaggio proveniente dal reattore ad alghe.
	 * Contiene lo stato del dispositivo.
	 * C'e' una piccola probabilita' di generare un errore, inviando l'opportuno messaggio di errore.
	 * @param a l'acquario che possiede il dispositivo di illuminazione
	 */
	private void reattoreAdAlgheMessage(Acquarium a) {
		String topic = T1 + a.getId() + T2 + a.getReattoreAdAlghe().getId() + "&" + a.getReattoreAdAlghe().getCodename();
		JsonObject data = new JsonObject();
		data.addProperty("status", a.getReattoreAdAlghe().getStatus());
		myGateway.sendToMqtt(data.toString(), topic);
		if( Math.random() <= 0.05 ) sendGenericError(topic);
	}
	
	/**
	 *  Metodo per inviare un messaggio MQTT contenente lo stato di errore "genericError".
	 * @param topic
	 */
	private void sendGenericError(String topic) {
		JsonObject data = new JsonObject();
		data.addProperty("error", "genericError");
		myGateway.sendToMqtt(data.toString(), topic);
	}

}
