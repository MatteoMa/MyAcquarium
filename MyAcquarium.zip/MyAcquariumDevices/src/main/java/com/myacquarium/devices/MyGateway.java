package com.myacquarium.devices;

import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.handler.annotation.Header;

/**
 * Classe per fornire un gateway di messaggistica come astrazione delle API di messaggistica.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@MessagingGateway(defaultRequestChannel = "mqttOutboundChannel")
public interface MyGateway {
	
	/**
	 * Metodo per inviare un messaggio MQTT.
	 * @param data il messaggio da inviare (rappresentazione in stringa di un oggetto JSON)
	 * @param topic il topic MQTT dove inviare il messaggio
	 */
	void sendToMqtt(String data, @Header(MqttHeaders.TOPIC) String topic);
	
}
