/** Fornisce classi necessarie per il lancio dell'applicazione Spring e per il supporto del protocollo MQTT. */
package com.myacquarium.devices;