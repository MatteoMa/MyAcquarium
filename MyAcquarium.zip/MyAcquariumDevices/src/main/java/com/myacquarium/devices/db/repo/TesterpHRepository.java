package com.myacquarium.devices.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.devices.db.TesterpH;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo TesterpH
 * che sara' implementata automaticamente da Spring in un Bean chiamato testerpHRepository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface TesterpHRepository extends CrudRepository<TesterpH, UUID> {}
