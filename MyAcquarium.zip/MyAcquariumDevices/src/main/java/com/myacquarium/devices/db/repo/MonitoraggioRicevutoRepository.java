package com.myacquarium.devices.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.devices.db.MonitoraggioRicevuto;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo MonitoraggioRicevuto
 * che sara' implementata automaticamente da Spring in un Bean chiamato monitoraggioRicevutoRepository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface MonitoraggioRicevutoRepository extends CrudRepository<MonitoraggioRicevuto, UUID> {}
