package com.myacquarium.devices.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.devices.db.sc.EntityWithId;

/**
 * Classe persistente dell'entita' DatiSensoriRicevuti rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class DatiSensoriRicevuti extends EntityWithId {
	
	/** Data e ora dell'ultima attivazione del distributore di cibo: indica l'ultimo pasto dato ai pesci. */
	@Column
	private java.time.LocalDateTime ddcLastMeal = null;
	
	/** Quantita' di cibo in percentuale contenuto nel distributore di cibo (0 vuoto, 100 pieno). */
	@Column
	private Integer ddcQuantity = -1;
	
	// --------------------------------------------------------------------------
	
	/** Stato del dispositivo di illuminazione (D illuminazione diurna, N illuminazione notturna, OFF spento). */
	@Column
	private String illStatus = "";
	
	/** Stato della pompa (ON attivo, OFF spento). */
	@Column
	private String pompaStatus = "";
	
	/** Stato del termoregolatore (C riscalda, F raffredda, OFF spento). */
	@Column
	private String termStatus = "";
	
	/** Stato del regolatore di livello (A aggiungi, R rimuovi, OFF spento). */
	@Column
	private String rdlStatus = "";
	
	/** Stato del reattore di calcio (ON acceso, OFF spento). */
	@Column
	private String rdcStatus = "";
	
	/** Stato dell'impianto di anidride carbonica (ON acceso, OFF spento). */
	@Column
	private String ico2Status = "";
	
	/** Stato del filtro di nitrati (ON acceso, OFF spento). */
	@Column
	private String fno3Status = "";
	
	/** Stato del filtro di fosfati (ON acceso, OFF spento). */
	@Column
	private String fpo4Status = "";
	
	/** Stato del filtro di silicati (ON acceso, OFF spento). */
	@Column
	private String fsio4Status = "";
	
	/** Stato dello schiumatoio (ON acceso, OFF spento). */
	@Column
	private String skiStatus = "";
	
	/** Stato del reattore ad alghe (ON acceso, OFF spento). */
	@Column
	private String raaStatus = "";
	
	// --------------------------------------------------------------------------
	
	/** Valore di temperatura inviato dal sistema di riscaldamento (in °C). */
	@Column
	private float temperature = -1;
	
	/** Valore di livello dell'acqua inviato dal regolatore di livello (in % di acqua totale presente nell'acquario). */
	@Column
	private float waterLevel = -1;
	
	/** Valore di calcio inviato dal tester di calcio (in mg/l). */
	@Column
	private float ca = -1;
	
	/** Valore di anidride carbonica inviato dal tester di anidride carbonica (in mg/l). */
	@Column
	private float co2 = -1;
	
	/** Valore di pH inviato dal tester di pH. */
	@Column
	private float ph = -1;
	
	/** Valore di nitrati inviato dal tester di nitrati (in mg/l). */
	@Column
	private float no3 = -1;
	
	/** Valore di fosfati inviato dal tester di fosfati (in mg/l). */
	@Column
	private float po4 = -1;
	
	/** Valore di silicati inviato dal tester di silicati (in mg/l). */
	@Column
	private float sio4 = -1;
	
	// --------------------------------------------------------------------------
	
	/** L'acquario a cui fan riferimento i dati ricevuti. */
	@OneToOne(mappedBy = "datiSensoriRicevuti")
    private Acquarium acquarium;
	
	// --------------------------------------------------------------------------
	
	/**
	 * Metodo per ottenere la data e l'ora dell'ultima attivazione del distributore di cibo.
	 * @return data e ora dell'ultima attivazione del distributore di cibo
	 */
	public java.time.LocalDateTime getDdcLastMeal() { return ddcLastMeal; }
	/**
	 * Metodo per impostare la data e l'ora dell'ultima attivazione del distributore di cibo,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param ddcLastMeal la data e l'ora dell'ultima attivazione del distributore di cibo
	 */
	public void setDdcLastMeal(java.time.LocalDateTime ddcLastMeal) { this.ddcLastMeal = ddcLastMeal; }
	
	/**
	 * Metodo per ottenere la quantita' di cibo in percentuale contenuto nel distributore di cibo.
	 * @return quantita' di cibo in percentuale contenuto nel distributore di cibo
	 */
	public Integer getDdcQuantity() { return ddcQuantity; }
	/**
	 * Metodo per impostare la quantita' di cibo in percentuale contenuto nel distributore di cibo,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param ddcQuantity la quantita' di cibo in percentuale contenuto nel distributore di cibo
	 */
	public void setDdcQuantity(Integer ddcQuantity) { this.ddcQuantity = ddcQuantity; }
	
	/**
	 * Metodo per ottenere lo stato del dispositivo di illuminazione.
	 * @return lo stato del dispositivo di illuminazione
	 */
	public String getIllStatus() { return illStatus; }
	/**
	 * Metodo per impostare lo stato del dispositivo di illuminazione,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param illStatus lo stato del dispositivo di illuminazione
	 */
	public void setIllStatus(String illStatus) { this.illStatus = illStatus; }
	
	/**
	 * Metodo per ottenere lo stato della pompa.
	 * @return lo stato della pompa
	 */
	public String getPompaStatus() { return pompaStatus; }
	/**
	 * Metodo per impostare lo stato della pompa,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param pompaStatus lo stato della pompa
	 */
	public void setPompaStatus(String pompaStatus) { this.pompaStatus = pompaStatus; }
	
	/**
	 * Metodo per ottenere lo stato del termoregolatore.
	 * @return lo stato del termoregolatore
	 */
	public String getTermStatus() { return termStatus; }
	/**
	 * Metodo per impostare lo stato del termoregolatore,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param termStatus lo stato del termoregolatore
	 */
	public void setTermStatus(String termStatus) { this.termStatus = termStatus; }
	
	/**
	 * Metodo per ottenere lo stato del regolatore di livello.
	 * @return lo stato del regolatore di livello
	 */
	public String getRdlStatus() { return rdlStatus; }
	/**
	 * Metodo per impostare lo stato del regolatore di livello,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param rdlStatus lo stato del regolatore di livello
	 */
	public void setRdlStatus(String rdlStatus) { this.rdlStatus = rdlStatus; }
	
	/**
	 * Metodo per ottenere lo stato del reattore di calcio.
	 * @return lo stato del reattore di calcio
	 */
	public String getRdcStatus() { return rdcStatus; }
	/**
	 * Metodo per impostare lo stato del reattore di calcio,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param rdcStatus lo stato del reattore di calcio
	 */
	public void setRdcStatus(String rdcStatus) { this.rdcStatus = rdcStatus; }
	
	/**
	 * Metodo per ottenere lo stato dell'impianto di anidride carbonica.
	 * @return lo stato dell'impianto di anidride carbonica
	 */
	public String getIco2Status() { return ico2Status; }
	/**
	 * Metodo per impostare lo stato dell'impianto di anidride carbonica,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param ico2Status lo stato dell'impianto di anidride carbonica
	 */
	public void setIco2Status(String ico2Status) { this.ico2Status = ico2Status; }
	
	/**
	 * Metodo per ottenere lo stato del filtro di nitrati.
	 * @return lo stato del filtro di nitrati
	 */
	public String getFno3Status() { return fno3Status; }
	/**
	 * Metodo per impostare lo stato del filtro di nitrati,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param fno3Status lo stato del filtro di nitrati
	 */
	public void setFno3Status(String fno3Status) { this.fno3Status = fno3Status; }
	
	/**
	 * Metodo per ottenere lo stato del filtro di fosfati.
	 * @return lo stato del filtro di fosfati
	 */
	public String getFpo4Status() { return fpo4Status; }
	/**
	 * Metodo per impostare lo stato del filtro di fosfati,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param fpo4Status lo stato del filtro di fosfati
	 */
	public void setFpo4Status(String fpo4Status) { this.fpo4Status = fpo4Status; }
	
	/**
	 * Metodo per ottenere lo stato del filtro di silicati.
	 * @return lo stato del filtro di silicati
	 */
	public String getFsio4Status() { return fsio4Status; }
	/**
	 * Metodo per impostare lo stato del filtro di silicati,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param fsio4Status lo stato del filtro di silicati
	 */
	public void setFsio4Status(String fsio4Status) { this.fsio4Status = fsio4Status; }
	
	/**
	 * Metodo per ottenere lo stato dello schiumatoio.
	 * @return lo stato dello schiumatoio
	 */
	public String getSkiStatus() { return skiStatus; }
	/**
	 * Metodo per impostare lo stato dello schiumatoio,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param skiStatus lo stato dello schiumatoio
	 */
	public void setSkiStatus(String skiStatus) { this.skiStatus = skiStatus; }
	
	/**
	 * Metodo per ottenere lo stato del reattore ad alghe.
	 * @return lo stato del reattore ad alghe
	 */
	public String getRaaStatus() { return raaStatus; }
	/**
	 * Metodo per impostare lo stato del reattore ad alghe,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param raaStatus lo stato del reattore ad alghe
	 */
	public void setRaaStatus(String raaStatus) { this.raaStatus = raaStatus; }
	
	/**
	 * Metodo per ottenere il valore di temperatura inviato dal sistema di riscaldamento.
	 * @return il valore di temperatura
	 */
	public float getTemperature() { return temperature; }
	/**
	 * Metodo per impostare il valore di temperatura inviato dal sistema di riscaldamento,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param temperature il valore di temperatura
	 */
	public void setTemperature(float temperature) { this.temperature = temperature; }
	
	/**
	 * Metodo per ottenere il valore di livello dell'acqua inviato dal regolatore di livello.
	 * @return il valore di livello dell'acqua
	 */
	public float getWaterLevel() { return waterLevel; }
	/**
	 * Metodo per impostare il valore di livello dell'acqua inviato dal regolatore di livello,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param waterLevel il valore di livello dell'acqua
	 */
	public void setWaterLevel(float waterLevel) { this.waterLevel = waterLevel; }
	
	/**
	 * Metodo per ottenere il valore di calcio inviato dal tester di calcio.
	 * @return il valore di calcio
	 */
	public float getCa() { return ca; }
	/**
	 * Metodo per impostare il valore di calcio inviato dal tester di calcio,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param ca il valore di calcio
	 */
	public void setCa(float ca) { this.ca = ca; }
	
	/**
	 * Metodo per ottenere il valore di anidride carbonica inviato dal tester di anidride carbonica.
	 * @return il valore di anidride carbonica
	 */
	public float getCo2() { return co2; }
	/**
	 * Metodo per impostare il valore di anidride carbonica inviato dal tester di anidride carbonica,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param co2 il valore di anidride carbonica
	 */
	public void setCo2(float co2) { this.co2 = co2; }
	
	/**
	 * Metodo per ottenere il valore di pH inviato dal tester di pH.
	 * @return il valore di pH
	 */
	public float getPh() { return ph; }
	/**
	 * Metodo per impostare il valore di pH inviato dal tester di pH,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param ph il valore di pH
	 */
	public void setPh(float ph) { this.ph = ph; }
	
	/**
	 * Metodo per ottenere il valore di nitrati inviato dal tester di nitrati.
	 * @return il valore di nitrati
	 */
	public float getNo3() { return no3; }
	/**
	 * Metodo per impostare il valore di nitrati inviato dal tester di nitrati,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param no3 il valore di nitrati
	 */
	public void setNo3(float no3) { this.no3 = no3; }
	
	/**
	 * Metodo per ottenere il valore di fosfati inviato dal tester di fosfati.
	 * @return il valore di fosfati
	 */
	public float getPo4() { return po4; }
	/**
	 * Metodo per impostare il valore di fosfati inviato dal tester di fosfati,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param po4 il valore di fosfati
	 */
	public void setPo4(float po4) { this.po4 = po4; }
	
	/**
	 * Metodo per ottenere il valore di silicati inviato dal tester di silicati.
	 * @return il valore di silicati
	 */
	public float getSio4() { return sio4; }
	/**
	 * Metodo per impostare il valore di silicati inviato dal tester di silicati,
	 * utilizzato per salvare nel database il dato ricevuto dal dispositivo, sovrascrivendo quello precedente ormai obsoleto.
	 * @param sio4 il valore di silicati
	 */
	public void setSio4(float sio4) { this.sio4 = sio4; }
	
	/**
	 * Metodo per ottenere l'acquario a cui fan riferimento i dati ricevuti.
	 * @return l'acquario a cui fan riferimento i dati ricevuti
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario a cui fan riferimento i dati ricevuti.
	 * @param acquarium l'acquario a cui fan riferimento i dati ricevuti
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
