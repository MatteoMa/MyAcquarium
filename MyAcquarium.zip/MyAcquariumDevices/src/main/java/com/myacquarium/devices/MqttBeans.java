package com.myacquarium.devices;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.UUID;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMDecryptorProvider;
import org.bouncycastle.openssl.PEMEncryptedKeyPair;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.openssl.jcajce.JcePEMDecryptorProviderBuilder;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.core.MessageProducer;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.integration.mqtt.inbound.MqttPahoMessageDrivenChannelAdapter;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.integration.mqtt.support.DefaultPahoMessageConverter;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessagingException;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.myacquarium.devices.db.DistributoreDiCibo;
import com.myacquarium.devices.db.repo.DistributoreDiCiboRepository;
import com.myacquarium.devices.db.FiltroNO3;
import com.myacquarium.devices.db.repo.FiltroNO3Repository;
import com.myacquarium.devices.db.FiltroPO4;
import com.myacquarium.devices.db.repo.FiltroPO4Repository;
import com.myacquarium.devices.db.FiltroSiO4;
import com.myacquarium.devices.db.repo.FiltroSiO4Repository;
import com.myacquarium.devices.db.Illuminazione;
import com.myacquarium.devices.db.repo.IlluminazioneRepository;
import com.myacquarium.devices.db.ImpiantoCO2;
import com.myacquarium.devices.db.repo.ImpiantoCO2Repository;
import com.myacquarium.devices.db.Pompa;
import com.myacquarium.devices.db.repo.PompaRepository;
import com.myacquarium.devices.db.ReattoreAdAlghe;
import com.myacquarium.devices.db.repo.ReattoreAdAlgheRepository;
import com.myacquarium.devices.db.ReattoreDiCalcio;
import com.myacquarium.devices.db.repo.ReattoreDiCalcioRepository;
import com.myacquarium.devices.db.RegolatoreDiLivello;
import com.myacquarium.devices.db.repo.RegolatoreDiLivelloRepository;
import com.myacquarium.devices.db.Schiumatoio;
import com.myacquarium.devices.db.repo.SchiumatoioRepository;
import com.myacquarium.devices.db.Termoregolatore;
import com.myacquarium.devices.db.repo.TermoregolatoreRepository;

/**
 * Classe per la configurazione di adattori di canali in entrata e in uscita per il supporto del protocollo MQTT.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Configuration
public class MqttBeans {
	
	/** Topic MQTT di sottoscrizione per la ricezione di messaggi. */
	private static final String SUBTOPIC = "myacquarium/+/devices/#";
	
	/** Autowired delle classe MyGateway per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private MyGateway myGateway;
	
	/** Autowired delle classe DistributoreDiCiboRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private DistributoreDiCiboRepository distributoreDiCiboRepository;
	/** Autowired delle classe IlluminazioneRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private IlluminazioneRepository illuminazioneRepository;
	/** Autowired delle classe PompaRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private PompaRepository pompaRepository;
	/** Autowired delle classe TermoregolatoreRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private TermoregolatoreRepository termoregolatoreRepository;
	/** Autowired delle classe RegolatoreDiLivelloRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private RegolatoreDiLivelloRepository regolatoreDiLivelloRepository;
	/** Autowired delle classe ReattoreDiCalcioRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private ReattoreDiCalcioRepository reattoreDiCalcioRepository;
	/** Autowired delle classe ImpiantoCO2Repository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private ImpiantoCO2Repository impiantoCO2Repository;
	/** Autowired delle classe FiltroNO3Repository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private FiltroNO3Repository filtroNO3Repository;
	/** Autowired delle classe FiltroPO4Repository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private FiltroPO4Repository filtroPO4Repository;
	/** Autowired delle classe FiltroSiO4Repository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private FiltroSiO4Repository filtroSiO4Repository;
	/** Autowired delle classe SchiumatoioRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private SchiumatoioRepository schiumatoioRepository;
	/** Autowired delle classe ReattoreAdAlgheRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private ReattoreAdAlgheRepository reattoreAdAlgheRepository;

	/**
	 * Metodo per la creazione di un Client MQTT configurando i suo parametri per la corretta connessione al server.
	 * L'username non e' necessario in quanto viene usato il nome comune (CN) del certificato come username per il controllo degli accessi,
	 * e la password non viene utilizzata perche' si presume che solo i client autenticati abbiano certificati validi.
	 * @return il Client MQTT configurato
	 */
    @Bean
    public MqttPahoClientFactory mqttClientFactory() {
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        MqttConnectOptions options = new MqttConnectOptions();
        options.setServerURIs(new String[] {"ssl://localhost:8883"});
        options.setCleanSession(true);
        options.setConnectionTimeout(30);
        options.setKeepAliveInterval(60);
        options.setAutomaticReconnect(true);
        try {
			String basePathOfClass = getClass().getProtectionDomain().getCodeSource().getLocation().getFile();
			SSLSocketFactory socketFactory = getSocketFactory(basePathOfClass+"/certificates/MQTT_ca.crt", basePathOfClass+"/certificates/MQTT_devices.crt", basePathOfClass+"/certificates/MQTT_devices.key", "");
			options.setSocketFactory(socketFactory);
		} catch (MqttException e) {
		    	e.printStackTrace();
	    } catch (Exception e) {
	        	e.printStackTrace();
	    }
        factory.setConnectionOptions(options);
        return factory;
    }
    
    /**
     * Metodo per la creazione di Socket SSL.
     * @param caCrtFile certificato dell'Autorita' Certificativa in formato CRT
     * @param crtFile certificato del client inviato al server per l'autenticazione in formato CRT
     * @param keyFile chiave privata del client in formato KEY
     * @param password password per decriptare la chiave privata del client (se necessaria)
     * @return Socket SSL creato
     * @throws Exception
     */
	private static SSLSocketFactory getSocketFactory(final String caCrtFile, final String crtFile, final String keyFile, final String password) throws Exception {
	    Security.addProvider(new BouncyCastleProvider());
	    X509Certificate caCert = null;
	
	    FileInputStream fis = new FileInputStream(caCrtFile);
	    BufferedInputStream bis = new BufferedInputStream(fis);
	    CertificateFactory cf = CertificateFactory.getInstance("X.509");
	
	    while (bis.available() > 0) {
	            caCert = (X509Certificate) cf.generateCertificate(bis);
	    }
	
	    bis = new BufferedInputStream(new FileInputStream(crtFile));
	    X509Certificate cert = null;
	    while (bis.available() > 0) {
	            cert = (X509Certificate) cf.generateCertificate(bis);
	    }
	
	    PEMParser pemParser = new PEMParser(new FileReader(keyFile));
	    Object object = pemParser.readObject();
	    PEMDecryptorProvider decProv = new JcePEMDecryptorProviderBuilder().build(password.toCharArray());
	    JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");
	    KeyPair key;
	    if (object instanceof PEMEncryptedKeyPair) {
	    	key = converter.getKeyPair(((PEMEncryptedKeyPair) object).decryptKeyPair(decProv));
	    }
	    else {
	    	key = converter.getKeyPair((PEMKeyPair) object);
	    }
	    pemParser.close();
	
	    KeyStore caKs = KeyStore.getInstance(KeyStore.getDefaultType());
	    caKs.load(null, null);
	    caKs.setCertificateEntry("ca-certificate", caCert);
	    TrustManagerFactory tmf = TrustManagerFactory.getInstance("X509");
	    tmf.init(caKs);
	
	    KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
	    ks.load(null, null);
	    ks.setCertificateEntry("certificate", cert);
	    ks.setKeyEntry("private-key", key.getPrivate(), password.toCharArray(), new java.security.cert.Certificate[] { cert });
	    KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
	    kmf.init(ks, password.toCharArray());
	
	    SSLContext context = SSLContext.getInstance("TLSv1.2");
	    context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
	
	    return context.getSocketFactory();
	}
	
	/**
	 * Metodo per definire i criteri per l'invio di messaggi.
	 * @return canale con la strategia predefinita RoundRobinLoadBalancingStrategy
	 */
	@Bean
    public MessageChannel mqttInputChannel() {
        return new DirectChannel();
    }

	/**
	 * Metodo per costruire l'interfaccia di base per il consumo di eventi in entrata
	 * @return l'interfaccia di base per il consumo di eventi in entrata
	 */
    @Bean
    public MessageProducer inbound() {
    	String clientId = "uuid-" + UUID.randomUUID().toString();
        MqttPahoMessageDrivenChannelAdapter adapter = new MqttPahoMessageDrivenChannelAdapter(clientId, mqttClientFactory(), SUBTOPIC);
        adapter.setCompletionTimeout(20000);
        adapter.setConverter(new DefaultPahoMessageConverter());
        adapter.setQos(2);
        adapter.setOutputChannel(mqttInputChannel());
        return adapter;
    }

    /**
     * Metodo in grado di gestire messaggi MQTT in arrivo sul canale specificato dal ServiceActivator.
     * @return semplice contratto per la gestione di un messaggio
     */
    @Bean
    @ServiceActivator(inputChannel = "mqttInputChannel")
    public MessageHandler handler() {
        return new MessageHandler() {

            @Override
            public void handleMessage(Message<?> message) throws MessagingException {
            	String topic = message.getHeaders().get(MqttHeaders.RECEIVED_TOPIC).toString();
            	JsonObject jsonMessage = new Gson().fromJson(message.getPayload().toString(), JsonObject.class);
            	String[] topics = topic.split("/");
            	String deviceAll = ""; UUID deviceId = UUID.randomUUID(); UUID acquariumId = UUID.randomUUID(); String deviceCodename = "";
            	if (topics.length == 4) {
            		deviceAll = topics[3]; acquariumId = UUID.fromString(topics[1]);
            		String[] d = deviceAll.split("&");
            		if (d.length == 2) deviceId = UUID.fromString(d[0]); deviceCodename = d[1];
            	}
            	JsonElement jsonStatusToSet = jsonMessage.get("setStatus");
            	if (jsonStatusToSet != null) {
            		String statusToSet = jsonStatusToSet.getAsString();
            		if (deviceCodename.equals("DDC100") || deviceCodename.equals("DDC200")) {
            			if (statusToSet.equals("ON") ) {
            				DistributoreDiCibo ddc = distributoreDiCiboRepository.findById(deviceId).orElse(null);
            				if (ddc != null) {
            					if( Math.random() <= 0.05 ) {
            						sendSetStatusError(acquariumId, deviceId, deviceCodename);
            					}
            					else {
            						ddc.setLastMeal(java.time.LocalDateTime.now());
                            		int quantity = ddc.getQuantity();
                            		if (quantity > 0) {
                            			ddc.setQuantity(quantity - 1);
                            			distributoreDiCiboRepository.save(ddc);
                            		}
            					}
            				}
            			}
                	}
                	if (deviceCodename.equals("LED120") || deviceCodename.equals("LED500") || deviceCodename.equals("LED850")) {
                		Illuminazione ill = illuminazioneRepository.findById(deviceId).orElse(null);
                		if (ill != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                    			ill.setStatus(statusToSet);
                    			illuminazioneRepository.save(ill);
                    		}
                		}
                	}
                	if (deviceCodename.equals("P1000") || deviceCodename.equals("P3000") || deviceCodename.equals("P5000")) {
                		Pompa p = pompaRepository.findById(deviceId).orElse(null);
                		if (p != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                    			p.setStatus(statusToSet);
                        		pompaRepository.save(p);
                    		}
                		}
                	}
                	if (deviceCodename.equals("SRR111") || deviceCodename.equals("SRR222")) {
                		Termoregolatore term = termoregolatoreRepository.findById(deviceId).orElse(null);
                		if (term != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                    			term.setStatus(statusToSet);
                        		termoregolatoreRepository.save(term);
                    		}
                		}
                	}
                	if (deviceCodename.equals("RDL10") || deviceCodename.equals("RDL20")) {
                		RegolatoreDiLivello rdl = regolatoreDiLivelloRepository.findById(deviceId).orElse(null);
                		if (rdl != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                    			rdl.setStatus(statusToSet);
                        		regolatoreDiLivelloRepository.save(rdl);
                    		}
                		}
                	}
                	if (deviceCodename.equals("RDC1")) {
                		ReattoreDiCalcio rdc = reattoreDiCalcioRepository.findById(deviceId).orElse(null);
                		if (rdc != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                    			rdc.setStatus(statusToSet);
                        		reattoreDiCalcioRepository.save(rdc);	
                    		}
                		}
                	}
                	if (deviceCodename.equals("ICO2")) {
                		ImpiantoCO2 ico2 = impiantoCO2Repository.findById(deviceId).orElse(null);
                		if (ico2 != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                    			ico2.setStatus(statusToSet);
                        		impiantoCO2Repository.save(ico2);
                    		}
                		}
                	}
                	if (deviceCodename.equals("F001NO3")) {
                		FiltroNO3 fno3 = filtroNO3Repository.findById(deviceId).orElse(null);
                		if (fno3 != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                    			fno3.setStatus(statusToSet);
                        		filtroNO3Repository.save(fno3);
                    		}
                		}
                	}
                	if (deviceCodename.equals("F001PO4")) {
                		FiltroPO4 fpo4 = filtroPO4Repository.findById(deviceId).orElse(null);
                		if (fpo4 != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                    			fpo4.setStatus(statusToSet);
                        		filtroPO4Repository.save(fpo4);
                    		}
                		}
                	}
                	if (deviceCodename.equals("F001SiO4")) {
                		FiltroSiO4 fsio4 = filtroSiO4Repository.findById(deviceId).orElse(null);
                		if (fsio4 != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                    			fsio4.setStatus(statusToSet);
                        		filtroSiO4Repository.save(fsio4);
                    		}
                		}
                	}
                	if (deviceCodename.equals("SKI1")) {
                		Schiumatoio ski = schiumatoioRepository.findById(deviceId).orElse(null);
                		if (ski != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                    			ski.setStatus(statusToSet);
                        		schiumatoioRepository.save(ski);
                    		}
                		}
                	}
                	if (deviceCodename.equals("RAA1")) {
                		ReattoreAdAlghe raa = reattoreAdAlgheRepository.findById(deviceId).orElse(null);
                		if (raa != null) {
                			if( Math.random() <= 0.05 ) {
                				sendSetStatusError(acquariumId, deviceId, deviceCodename);
                			}
                    		else {
                        		raa.setStatus(statusToSet);
                        		reattoreAdAlgheRepository.save(raa);
                    		}
                		}
                	}
            	}
            }
            
        };
    }
    
    /**
     * Metodo per inviare un messaggio MQTT contenente lo stato di errore "setStatusError".
     * @param acquariumId chiave primaria dell'acquario, destinatario del messaggio
     * @param deviceId chiave primaria del device, mittente del messaggio
     * @param deviceCodename nome in codice del device, mittente del messaggio
     */
	private void sendSetStatusError(UUID acquariumId, UUID deviceId, String deviceCodename) {
		String topic = "myacquarium/" + acquariumId + "/agent/" + deviceId + "&" + deviceCodename;
		JsonObject data = new JsonObject();
		data.addProperty("error", "setStatusError");
		myGateway.sendToMqtt(data.toString(), topic);
	}

	/**
	 * Metodo per definire i criteri per l'invio di messaggi.
	 * @return canale con la strategia predefinita RoundRobinLoadBalancingStrategy
	 */
    @Bean
    public MessageChannel mqttOutboundChannel() {
        return new DirectChannel();
    }
    
	/**
	 * Metodo per costruire l'interfaccia di base per gli eventi in uscita
	 * @return l'interfaccia di base per gli eventi in uscita
	 */
    @Bean
    @ServiceActivator(inputChannel = "mqttOutboundChannel")
    public MessageHandler mqttOutbound() {
    	String clientId = "uuid-" + UUID.randomUUID().toString();
        MqttPahoMessageHandler messageHandler = new MqttPahoMessageHandler(clientId, mqttClientFactory());
        messageHandler.setAsync(true);
        messageHandler.setDefaultTopic("#");
        return messageHandler;
    }

}
