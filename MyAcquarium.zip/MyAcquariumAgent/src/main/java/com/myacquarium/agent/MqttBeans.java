package com.myacquarium.agent;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.UUID;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMDecryptorProvider;
import org.bouncycastle.openssl.PEMEncryptedKeyPair;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.openssl.jcajce.JcePEMDecryptorProviderBuilder;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.core.MessageProducer;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.integration.mqtt.inbound.MqttPahoMessageDrivenChannelAdapter;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.integration.mqtt.support.DefaultPahoMessageConverter;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessagingException;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.myacquarium.agent.db.Acquarium;
import com.myacquarium.agent.db.Avviso;
import com.myacquarium.agent.db.repo.AcquariumRepository;
import com.myacquarium.agent.db.DatiSensoriRicevuti;
import com.myacquarium.agent.db.repo.DatiSensoriRicevutiRepository;
import com.myacquarium.agent.db.RegoleDiControllo;

/**
 * Classe per la configurazione di adattori di canali in entrata e in uscita per il supporto del protocollo MQTT.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Configuration
public class MqttBeans {
	
	/** Topic MQTT di sottoscrizione per la ricezione di messaggi. */
	private static final String SUBTOPIC1 = "myacquarium/+/agent/#";
	
	/** Autowired delle classe MyGateway per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private MyGateway myGateway;
	
	/** Autowired delle classe AcquariumRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private AcquariumRepository acquariumRepository;
	
	/** Autowired delle classe DatiSensoriRicevutiRepository per poter accedere a oggetti e metodi di questa classe. */
	@Autowired
	private DatiSensoriRicevutiRepository datiSensoriRicevutiRepository;

	/**
	 * Metodo per la creazione di un Client MQTT configurando i suo parametri per la corretta connessione al server.
	 * L'username non e' necessario in quanto viene usato il nome comune (CN) del certificato come username per il controllo degli accessi,
	 * e la password non viene utilizzata perche' si presume che solo i client autenticati abbiano certificati validi.
	 * @return il Client MQTT configurato
	 */
    @Bean
    public MqttPahoClientFactory mqttClientFactory() {
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        MqttConnectOptions options = new MqttConnectOptions();
        options.setServerURIs(new String[] {"ssl://localhost:8883"});
        options.setCleanSession(true);
        options.setConnectionTimeout(30);
        options.setKeepAliveInterval(60);
        options.setAutomaticReconnect(true);
        try {
        	InputStream inCaCrtFile = getClass().getResourceAsStream("/certificates/MQTT_ca.crt");
        	InputStream inCrtFile = getClass().getResourceAsStream("/certificates/MQTT_agent.crt");
        	InputStream inKeyFile = getClass().getResourceAsStream("/certificates/MQTT_agent.key");
        	SSLSocketFactory socketFactory = getSocketFactory(inCaCrtFile, inCrtFile, inKeyFile, "");
			options.setSocketFactory(socketFactory);
		} catch (Exception e) {
	    		e.printStackTrace();
	    }
        factory.setConnectionOptions(options);
        return factory;
    }
    
    /**
     * Metodo per la creazione di Socket SSL.
     * @param inCaCrtFile flusso di byte in ingresso del certificato dell'Autorita' Certificativa in formato CRT
     * @param inCrtFile flusso di byte in ingresso del certificato del client in formato CRT inviato al server per l'autenticazione
     * @param inKeyFile flusso di byte in ingresso della chiave privata del client in formato KEY
     * @param password password per decriptare la chiave privata del client (se necessaria)
     * @return il Socket SSL creato
     * @throws Exception
     */
	private static SSLSocketFactory getSocketFactory(final InputStream inCaCrtFile, final InputStream inCrtFile, final InputStream inKeyFile, final String password) throws Exception {
	    Security.addProvider(new BouncyCastleProvider());
	    X509Certificate caCert = null;
	
	    BufferedInputStream bis = new BufferedInputStream(inCaCrtFile);
	    CertificateFactory cf = CertificateFactory.getInstance("X.509");
	
	    while (bis.available() > 0) {
	            caCert = (X509Certificate) cf.generateCertificate(bis);
	    }
	
	    bis = new BufferedInputStream(inCrtFile);
	    X509Certificate cert = null;
	    while (bis.available() > 0) {
	            cert = (X509Certificate) cf.generateCertificate(bis);
	    }
	    
	    Reader rKeyFile = new InputStreamReader(inKeyFile);
	    PEMParser pemParser = new PEMParser(rKeyFile);
	    Object object = pemParser.readObject();
	    PEMDecryptorProvider decProv = new JcePEMDecryptorProviderBuilder().build(password.toCharArray());
	    JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");
	    KeyPair key;
	    if (object instanceof PEMEncryptedKeyPair) {
	    	key = converter.getKeyPair(((PEMEncryptedKeyPair) object).decryptKeyPair(decProv));
	    }
	    else {
	    	key = converter.getKeyPair((PEMKeyPair) object);
	    }
	    pemParser.close();
	
	    KeyStore caKs = KeyStore.getInstance(KeyStore.getDefaultType());
	    caKs.load(null, null);
	    caKs.setCertificateEntry("ca-certificate", caCert);
	    TrustManagerFactory tmf = TrustManagerFactory.getInstance("X509");
	    tmf.init(caKs);
	
	    KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
	    ks.load(null, null);
	    ks.setCertificateEntry("certificate", cert);
	    ks.setKeyEntry("private-key", key.getPrivate(), password.toCharArray(), new java.security.cert.Certificate[] { cert });
	    KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
	    kmf.init(ks, password.toCharArray());
	
	    SSLContext context = SSLContext.getInstance("TLSv1.2");
	    context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
	
	    return context.getSocketFactory();
	}
	
	/**
	 * Metodo per definire i criteri per l'invio di messaggi.
	 * @return un canale con la strategia predefinita RoundRobinLoadBalancingStrategy
	 */
	@Bean
    public MessageChannel mqttInputChannel() {
        return new DirectChannel();
    }

	/**
	 * Metodo per costruire l'interfaccia di base per l'invio di messaggi.
	 * @return l'interfaccia di base per l'invio di messaggi
	 */
    @Bean
    public MessageProducer inbound() {
    	String clientId = "uuid-" + UUID.randomUUID().toString();
        MqttPahoMessageDrivenChannelAdapter adapter = new MqttPahoMessageDrivenChannelAdapter(clientId, mqttClientFactory(), SUBTOPIC1);
        adapter.setCompletionTimeout(20000);
        adapter.setConverter(new DefaultPahoMessageConverter());
        adapter.setQos(2);
        adapter.setOutputChannel(mqttInputChannel());
        return adapter;
    }

    /**
     * Metodo in grado di gestire messaggi MQTT in arrivo sul canale specificato dal ServiceActivator.
     * @return semplice contratto per la gestione di un messaggio
     */
    @Bean
    @ServiceActivator(inputChannel = "mqttInputChannel")
    public MessageHandler handler() {
        return new MessageHandler() {

            @Override
            public void handleMessage(Message<?> message) throws MessagingException {
            	String topic = message.getHeaders().get(MqttHeaders.RECEIVED_TOPIC).toString();
            	JsonObject jsonMessage = new Gson().fromJson(message.getPayload().toString(), JsonObject.class);
            	String[] topics = topic.split("/");
            	String mitt = ""; UUID acquariumId = UUID.randomUUID(); String deviceCodename = "";
            	if (topics.length == 4) {
            		mitt = topics[3]; acquariumId = UUID.fromString(topics[1]);
            		String[] d = mitt.split("&");
            		if (d.length == 2) deviceCodename = d[1];
            	}
            	RegoleDiControllo rules = getRules(acquariumId);
            	if (rules != null) {
            		if (deviceCodename.equals("DDC100") || deviceCodename.equals("DDC200")) {
                    	activateFoodDispenser(jsonMessage, topic, rules);
            			JsonElement jsonLastMeal = jsonMessage.get("lastMeal");
            			JsonElement jsonQuantity = jsonMessage.get("quantity");
            	    	if (jsonLastMeal != null || jsonQuantity != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setDdcLastMeal(java.time.LocalDateTime.parse(jsonLastMeal.getAsString()));
            	    			dsr.setDdcQuantity(jsonQuantity.getAsInt());
            	    			datiSensoriRicevutiRepository.save(dsr);
            	    		}
            	    	}
                    }
            		if (deviceCodename.equals("LED120") || deviceCodename.equals("LED500") || deviceCodename.equals("LED850")) {
                    	activateLight(jsonMessage, topic, rules);
                    	JsonElement jsonStatus = jsonMessage.get("status");
            	    	if (jsonStatus != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setIllStatus(jsonStatus.getAsString());
            	    			datiSensoriRicevutiRepository.save(dsr);
            	    		}
            	    	}
                    }
            		if (deviceCodename.equals("P1000") || deviceCodename.equals("P3000") || deviceCodename.equals("P5000")) {
                    	activatePump(jsonMessage, topic, rules);
                    	JsonElement jsonStatus = jsonMessage.get("status");
                    	if (jsonStatus != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setPompaStatus(jsonStatus.getAsString());
            	    			datiSensoriRicevutiRepository.save(dsr);
            	    		}
            	    	}
                    }
            		if (deviceCodename.equals("SRR111") || deviceCodename.equals("SRR222")) {
                    	activateThermoregulator(jsonMessage, topic, rules);
                    	JsonElement jsonStatus = jsonMessage.get("status");
            			JsonElement jsonTemperature = jsonMessage.get("temperature");
            	    	if (jsonStatus != null || jsonTemperature != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setTermStatus(jsonStatus.getAsString());
            	    			dsr.setTemperature(jsonTemperature.getAsFloat());
            	    			datiSensoriRicevutiRepository.save(dsr);
                            	sendOnlyDataToMonitoring(jsonMessage, topic, "status");
            	    		}
            	    	}
                    }
            		if (deviceCodename.equals("RDL10") || deviceCodename.equals("RDL20")) {
                    	activateLevelController(jsonMessage, topic, rules);
                    	JsonElement jsonStatus = jsonMessage.get("status");
            			JsonElement jsonWaterLevel = jsonMessage.get("waterLevel");
            	    	if (jsonStatus != null || jsonWaterLevel != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setRdlStatus(jsonStatus.getAsString());
            	    			dsr.setWaterLevel(jsonWaterLevel.getAsFloat());
            	    			datiSensoriRicevutiRepository.save(dsr);
            	    			sendOnlyDataToMonitoring(jsonMessage, topic, "status");
            	    		}
            	    	}
                    }
            		if (deviceCodename.equals("T001CA")) {
            			JsonElement jsonCa = jsonMessage.get("ca");
            	    	if (jsonCa != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setCa(jsonCa.getAsFloat());
            	    			datiSensoriRicevutiRepository.save(dsr);
                	    		myGateway.sendToMqtt(jsonMessage.toString(), topic.replace("agent","monitoring"));
            	    		}
            	    	}
            		}
            		if (deviceCodename.equals("T001CO2")) {
            			JsonElement jsonCo2 = jsonMessage.get("co2");
            	    	if (jsonCo2 != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setCo2(jsonCo2.getAsFloat());
            	    			datiSensoriRicevutiRepository.save(dsr);
                	    		myGateway.sendToMqtt(jsonMessage.toString(), topic.replace("agent","monitoring"));
            	    		}
            	    	}
            		}
            		if (deviceCodename.equals("T001PH")) {
            			JsonElement jsonPh = jsonMessage.get("ph");
            	    	if (jsonPh != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setPh(jsonPh.getAsFloat());
            	    			datiSensoriRicevutiRepository.save(dsr);
                	    		myGateway.sendToMqtt(jsonMessage.toString(), topic.replace("agent","monitoring"));
            	    		}
            	    	}
            		}
            		if (deviceCodename.equals("T001NO3")) {
            			JsonElement jsonNo3 = jsonMessage.get("no3");
            	    	if (jsonNo3 != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setNo3(jsonNo3.getAsFloat());
            	    			datiSensoriRicevutiRepository.save(dsr);
                	    		myGateway.sendToMqtt(jsonMessage.toString(), topic.replace("agent","monitoring"));
            	    		}
            	    	}
            		}
            		if (deviceCodename.equals("T001PO4")) {
            			JsonElement jsonPo4 = jsonMessage.get("po4");
            	    	if (jsonPo4 != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setPo4(jsonPo4.getAsFloat());
            	    			datiSensoriRicevutiRepository.save(dsr);
                	    		myGateway.sendToMqtt(jsonMessage.toString(), topic.replace("agent","monitoring"));
            	    		}
            	    	}
            		}
            		if (deviceCodename.equals("T001SIO4")) {
            			JsonElement jsonSio4 = jsonMessage.get("sio4");
            	    	if (jsonSio4 != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setSio4(jsonSio4.getAsFloat());
            	    			datiSensoriRicevutiRepository.save(dsr);
                	    		myGateway.sendToMqtt(jsonMessage.toString(), topic.replace("agent","monitoring"));
            	    		}
            	    	}
            		}
            		if (deviceCodename.equals("RDC1")) {
            			JsonElement jsonStatus = jsonMessage.get("status");
            			Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
        	    		if (acquarium != null) {
        	    			float ca = acquarium.getDatiSensoriRicevuti().getCa();
        	    			activateCalciumReactor(jsonMessage, topic, rules, ca);
        	    			if (jsonStatus != null) {
                	    		DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
                	    		dsr.setRdcStatus(jsonStatus.getAsString());
                	    		datiSensoriRicevutiRepository.save(dsr);
                	    	}
        	    		}
                    }
            		if (deviceCodename.equals("ICO2")) {
            			JsonElement jsonStatus = jsonMessage.get("status");
            			Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
        	    		if (acquarium != null) {
        	    			float co2 = acquarium.getDatiSensoriRicevuti().getCo2();
        	    			activateCO2Plant(jsonMessage, topic, rules, co2);
        	    			if (jsonStatus != null) {
                	    		DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
                	    		dsr.setIco2Status(jsonStatus.getAsString());
                	    		datiSensoriRicevutiRepository.save(dsr);
                	    	}
        	    		}
                    }
            		if (deviceCodename.equals("F001NO3")) {
            			JsonElement jsonStatus = jsonMessage.get("status");
            			Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
        	    		if (acquarium != null) {
        	    			float no3 = acquarium.getDatiSensoriRicevuti().getNo3();
        	    			activateNO3Filter(jsonMessage, topic, rules, no3);
        	    			if (jsonStatus != null) {
                	    		DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
                	    		dsr.setFno3Status(jsonStatus.getAsString());
                	    		datiSensoriRicevutiRepository.save(dsr);
                	    	}
        	    		}
                    }
            		if (deviceCodename.equals("F001PO4")) {
            			JsonElement jsonStatus = jsonMessage.get("status");
            			Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
        	    		if (acquarium != null) {
        	    			float po4 = acquarium.getDatiSensoriRicevuti().getPo4();
        	    			activatePO4Filter(jsonMessage, topic, rules, po4);
        	    			if (jsonStatus != null) {
                	    		DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
                	    		dsr.setFpo4Status(jsonStatus.getAsString());
                	    		datiSensoriRicevutiRepository.save(dsr);
                	    	}
        	    		}
                    }
            		if (deviceCodename.equals("F001SIO4")) {
            			JsonElement jsonStatus = jsonMessage.get("status");
            			Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
        	    		if (acquarium != null) {
        	    			float sio4 = acquarium.getDatiSensoriRicevuti().getSio4();
        	    			activateSiO4Filter(jsonMessage, topic, rules, sio4);
        	    			if (jsonStatus != null) {
                	    		DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
                	    		dsr.setFsio4Status(jsonStatus.getAsString());
                	    		datiSensoriRicevutiRepository.save(dsr);
                	    	}
        	    		}
                    }
            		if (deviceCodename.equals("SKI1")) {
            			activateSkimmer(jsonMessage, topic, rules);
            			JsonElement jsonStatus = jsonMessage.get("status");
                    	if (jsonStatus != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setSkiStatus(jsonStatus.getAsString());
            	    			datiSensoriRicevutiRepository.save(dsr);
            	    		}
            	    	}
                    }
            		if (deviceCodename.equals("RAA1")) {
            			activateAlgaeReactor(jsonMessage, topic, rules);
            			JsonElement jsonStatus = jsonMessage.get("status");
                    	if (jsonStatus != null) {
            	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
            	    		if (acquarium != null) {
            	    			DatiSensoriRicevuti dsr = acquarium.getDatiSensoriRicevuti();
            	    			dsr.setRaaStatus(jsonStatus.getAsString());
            	    			datiSensoriRicevutiRepository.save(dsr);
            	    		}
            	    	}
                    }
        			JsonElement jsonError = jsonMessage.get("error");
                	if (jsonError != null) {
        	    		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
        	    		if (acquarium != null) {
        	    			acquarium.addAvviso(new Avviso(deviceCodename, jsonError.getAsString()));
        	    			acquariumRepository.save(acquarium);
        	    		}
        	    	}
            	}
            }

        };
    }

	/**
	 * Metodo per definire i criteri per l'invio di messaggi.
	 * @return canale con la strategia predefinita RoundRobinLoadBalancingStrategy
	 */
    @Bean
    public MessageChannel mqttOutboundChannel() {
        return new DirectChannel();
    }
    
	/**
	 * Metodo per costruire l'interfaccia di base per la gestione dei messaggi.
	 * @return l'interfaccia di base per la gestione dei messaggi
	 */
    @Bean
    @ServiceActivator(inputChannel = "mqttOutboundChannel")
    public MessageHandler mqttOutbound() {
    	String clientId = "uuid-" + UUID.randomUUID().toString();
        MqttPahoMessageHandler messageHandler = new MqttPahoMessageHandler(clientId, mqttClientFactory());
        messageHandler.setAsync(true);
        messageHandler.setDefaultTopic("#");
        return messageHandler;
    }
    
    // -----------------------------------------------------------------------------------------------------------------

    /**
     * Metodo per ottenere le regole di controllo dell'acquario.
     * @param acquariumId l'acquario da cui prelevare le regole di controllo
     * @return le regole di controllo dell'acquario
     */
    private RegoleDiControllo getRules (UUID acquariumId) {
		Acquarium acquarium = acquariumRepository.findById(acquariumId).orElse(null);
		if (acquarium != null) return acquarium.getRegoleDiControllo();
		return null;
	}
	
    /**
     * Metodo per inviare solo i dati al sistema di monitoraggio escludendo lo stato dei dispositivi.
     * @param jsonMessage il messaggio ricevuto da gestire e inoltrare
     * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
     * @param remove elemento JSON presente nel messaggio ricevuto da rimuovere prima di inoltrare il messaggio
     */
	private void sendOnlyDataToMonitoring (JsonObject jsonMessage, String topic, String remove) {
		JsonElement jsonStatus = jsonMessage.get("status");
    	if (jsonStatus != null) {
    		JsonObject save = jsonMessage.deepCopy();
    		save.remove(remove);
    		myGateway.sendToMqtt(save.toString(), topic.replace("agent","monitoring"));
    	}
	}
	
	/**
	 * Metodo per attivare il distributore di cibo secondo le regole di controllo dell'acquario.
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activateFoodDispenser (JsonObject jsonMessage, String topic, RegoleDiControllo rules) {
		JsonElement jsonLastMeal = jsonMessage.get("lastMeal");
		if (jsonLastMeal != null) {
			java.time.LocalTime lastMeal = java.time.LocalDateTime.parse(jsonLastMeal.getAsString()).toLocalTime();
			java.time.LocalTime actualTime = java.time.LocalTime.now();
			java.time.LocalTime ciboTime1 = rules.getCiboTime1();
			java.time.LocalTime ciboTime2 = rules.getCiboTime2();
			if (actualTime.isAfter(ciboTime1) && lastMeal.isBefore(ciboTime1)) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "ON"); myGateway.sendToMqtt(data.toString(), newTopic);
			}
			if (actualTime.isAfter(ciboTime2) && lastMeal.isBefore(ciboTime2)) {
				String newTopic = topic.replace("agent","devices");
				JsonObject data = new JsonObject(); data.addProperty("setStatus", "ON"); myGateway.sendToMqtt(data.toString(), newTopic);
			}
		}
	}
	
	/**
	 * Metodo per attivare il dispositivo di illuminazione secondo le regole di controllo dell'acquario.
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activateLight (JsonObject jsonMessage, String topic, RegoleDiControllo rules) {
		JsonElement jsonStatus = jsonMessage.get("status");
		if (jsonStatus != null) {
			java.time.LocalTime actualTime = java.time.LocalTime.now();
			if (actualTime.isAfter(rules.getInizioLuceDiurna()) && actualTime.isBefore(rules.getInizioLuceNotturna())) {
				if (jsonStatus.getAsString().equals("OFF") || jsonStatus.getAsString().equals("N")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "D"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
			if (actualTime.isAfter(rules.getInizioLuceNotturna()) || actualTime.isBefore(rules.getInizioLuceDiurna())) {
				if (jsonStatus.getAsString().equals("OFF") || jsonStatus.getAsString().equals("D")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "N"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
		}
	}
	
	/**
	 * Metodo per attivare la pompa (deve sempre essere attiva).
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activatePump (JsonObject jsonMessage, String topic, RegoleDiControllo rules) {
		JsonElement jsonStatus = jsonMessage.get("status");
		if (jsonStatus != null) {
			if (jsonStatus.getAsString().equals("OFF")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "ON"); myGateway.sendToMqtt(data.toString(), newTopic);
			}
		}
	}
	
	/**
	 * Metodo per attivare il termoregolatore secondo le regole di controllo dell'acquario.
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activateThermoregulator (JsonObject jsonMessage, String topic, RegoleDiControllo rules) {
		JsonElement jsonStatus = jsonMessage.get("status");
		JsonElement jsonTemperature = jsonMessage.get("temperature");
		if (jsonStatus != null && jsonTemperature != null) {
			if (jsonTemperature.getAsFloat() <= rules.getMinTemp()) {
				if (jsonStatus.getAsString().equals("OFF") || jsonStatus.getAsString().equals("F")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "C"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
			if (jsonTemperature.getAsFloat() > rules.getMinTemp() && jsonTemperature.getAsFloat() < rules.getMaxTemp()) {
				if (jsonStatus.getAsString().equals("F") || jsonStatus.getAsString().equals("C")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "OFF"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
			if (jsonTemperature.getAsFloat() >= rules.getMaxTemp()) {
				if (jsonStatus.getAsString().equals("OFF") || jsonStatus.getAsString().equals("C")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "F"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
		}
	}
	
	/**
	 * Metodo per attivare il regolatore di livello secondo le regole di controllo dell'acquario.
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activateLevelController (JsonObject jsonMessage, String topic, RegoleDiControllo rules) {
		JsonElement jsonStatus = jsonMessage.get("status");
		JsonElement jsonWaterLevel = jsonMessage.get("waterLevel");
		if (jsonStatus != null && jsonWaterLevel != null) {
			if (jsonWaterLevel.getAsFloat() <= rules.getMinWaterLevel()) {
				if (jsonStatus.getAsString().equals("OFF") || jsonStatus.getAsString().equals("R")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "A"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
			if (jsonWaterLevel.getAsFloat() > rules.getMinWaterLevel() && jsonWaterLevel.getAsFloat() < rules.getMaxWaterLevel()) {
				if (jsonStatus.getAsString().equals("A") || jsonStatus.getAsString().equals("R")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "OFF"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
			if (jsonWaterLevel.getAsFloat() >= rules.getMaxWaterLevel()) {
				if (jsonStatus.getAsString().equals("OFF") || jsonStatus.getAsString().equals("A")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "R"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
		}
	}
	
	/**
	 * Metodo per attivare il reattore di calcio secondo le regole di controllo dell'acquario.
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activateCalciumReactor (JsonObject jsonMessage, String topic, RegoleDiControllo rules, float ca) {
		JsonElement jsonStatus = jsonMessage.get("status");
		if (jsonStatus != null && ca != -1) {
			if (ca < rules.getMinCa()) {
				if (jsonStatus.getAsString().equals("OFF")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "ON"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
			if (ca > rules.getMaxCa()) {
				if (jsonStatus.getAsString().equals("ON")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "OFF"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
		}
	}
	
	/**
	 * Metodo per attivare l'impianto di anidride carbonica secondo le regole di controllo dell'acquario.
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activateCO2Plant (JsonObject jsonMessage, String topic, RegoleDiControllo rules, float co2) {
		JsonElement jsonStatus = jsonMessage.get("status");
		if (jsonStatus != null && co2 != -1) {
			if (co2 < rules.getMinCO2()) {
				if (jsonStatus.getAsString().equals("OFF")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "ON"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
			if (co2 > rules.getMaxCO2()) {
				if (jsonStatus.getAsString().equals("ON")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "OFF"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
		}
	}
	
	/**
	 * Metodo per attivare il filtro di nitrati secondo le regole di controllo dell'acquario.
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activateNO3Filter (JsonObject jsonMessage, String topic, RegoleDiControllo rules, float no3) {
		JsonElement jsonStatus = jsonMessage.get("status");
		if (jsonStatus != null && no3 != -1) {
			if (no3 > rules.getMaxNO3()) {
				if (jsonStatus.getAsString().equals("OFF")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "ON"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
			if (no3 < rules.getMinNO3()) {
				if (jsonStatus.getAsString().equals("ON")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "OFF"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
		}
	}
	
	/**
	 * Metodo per attivare il filtro di fosfati secondo le regole di controllo dell'acquario.
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activatePO4Filter (JsonObject jsonMessage, String topic, RegoleDiControllo rules, float po4) {
		JsonElement jsonStatus = jsonMessage.get("status");
		if (jsonStatus != null && po4 != -1) {
			if (po4 > rules.getMaxPO4()) {
				if (jsonStatus.getAsString().equals("OFF")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "ON"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
			if (po4 < rules.getMinPO4()) {
				if (jsonStatus.getAsString().equals("ON")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "OFF"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
		}
	}
	
	/**
	 * Metodo per attivare il filtro di silicati secondo le regole di controllo dell'acquario.
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activateSiO4Filter (JsonObject jsonMessage, String topic, RegoleDiControllo rules, float sio4) {
		JsonElement jsonStatus = jsonMessage.get("status");
		if (jsonStatus != null && sio4 != -1) {
			if (sio4 > rules.getMaxSiO4()) {
				if (jsonStatus.getAsString().equals("OFF")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "ON"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
			if (sio4 < rules.getMinSiO4()) {
				if (jsonStatus.getAsString().equals("ON")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "OFF"); myGateway.sendToMqtt(data.toString(), newTopic);
				}
			}
		}
	}
	
	/**
	 * Metodo per attivare lo schiumatoio (rimane sempre attivo).
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activateSkimmer (JsonObject jsonMessage, String topic, RegoleDiControllo rules) {
		JsonElement jsonStatus = jsonMessage.get("status");
		if (jsonStatus != null) {
			if (jsonStatus.getAsString().equals("OFF")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "ON"); myGateway.sendToMqtt(data.toString(), newTopic);
			}
		}
	}
	
	/**
	 * Metodo per attivare il reattore ad alghe (rimane sempre attivo).
	 * @param jsonMessage il messaggio ricevuto da gestire per capire l'azione da compiere
	 * @param topic il topic MQTT di sottoscrizione, da modificare per inoltrare il messaggio
	 * @param rules le regole di controllo dell'acquario
	 */
	private void activateAlgaeReactor (JsonObject jsonMessage, String topic, RegoleDiControllo rules) {
		JsonElement jsonStatus = jsonMessage.get("status");
		if (jsonStatus != null) {
			if (jsonStatus.getAsString().equals("OFF")) {
					String newTopic = topic.replace("agent","devices");
					JsonObject data = new JsonObject(); data.addProperty("setStatus", "ON"); myGateway.sendToMqtt(data.toString(), newTopic);
			}
		}
	}
    
}
