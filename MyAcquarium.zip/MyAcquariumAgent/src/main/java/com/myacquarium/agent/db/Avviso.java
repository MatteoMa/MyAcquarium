package com.myacquarium.agent.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.myacquarium.agent.db.sc.EntityWithId;

/**
 * Classe persistente dell'entita' Avviso rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class Avviso extends EntityWithId {

	/** Il codice del device che ha inviato l'errore (obbligatorio). */
	@Column
	@NotNull
	private String device;
	
	/** Il codice di errore inviato dal device (genericError/setStatusError, obbligatorio). */
	@Column
	@NotNull
	private String errorCode;
	
	/** L'acquario a cui fa riferimento l'avviso. */
    @ManyToOne(fetch = FetchType.LAZY)
    private Acquarium acquarium;
    
    /** Costruttore di default della classe Avviso. */
    public Avviso() { super(); }
    
    /**
     * Costruttore della classe Avviso con i parametri device ed errorCode.
     * @param device il codice del device che ha inviato l'errore
     * @param errorCode il codice di errore inviato dal device
     */
	public Avviso(String device, String errorCode) {
		this.device = device;
		this.errorCode = errorCode;
	}

	/**
	 * Metodo per ottenere il codice del device che ha inviato l'errore.
	 * @return il codice del device che ha inviato l'errore
	 */
	public String getDevice() { return device; }
	/**
	 * Metodo per impostare il codice del device che ha inviato l'errore.
	 * @param device il codice del device che ha inviato l'errore
	 */
	public void setDevice(String device) { this.device = device; }

	/**
	 * Metodo per ottenere il codice di errore inviato dal device.
	 * @return il codice di errore inviato dal device
	 */
	public String getErrorCode() { return errorCode; }
	/**
	 * Metodo per impostare il codice di errore inviato dal device.
	 * @param errorCode il codice di errore inviato dal device
	 */
	public void setErrorCode(String errorCode) { this.errorCode = errorCode; }

	/**
	 * Metodo per ottenere l'acquario a cui fa riferimento l'avviso.
	 * @return l'acquario a cui fa riferimento l'avviso
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario a cui fa riferimento l'avviso.
	 * @param acquarium l'acquario a cui fa riferimento l'avviso
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
