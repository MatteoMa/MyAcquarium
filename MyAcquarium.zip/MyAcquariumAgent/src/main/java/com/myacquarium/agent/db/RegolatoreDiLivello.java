package com.myacquarium.agent.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.agent.db.sc.Device;

/**
 * Classe persistente dell'entita' RegolatoreDiLivello rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class RegolatoreDiLivello extends Device {
	
	/** Stato del regolatore di livello (A aggiungi, R rimuovi, OFF spento). */
	@Column(columnDefinition = "varchar(255) default 'OFF'")
	private String status = "OFF";
	
	/** L'acquario che possiede il regolatore di livello. */
	@OneToOne(mappedBy = "regolatoreDiLivello")
    private Acquarium acquarium;
	
	/**
	 * Metodo per ottenere lo stato del regolatore di livello.
	 * @return lo stato del regolatore di livello
	 */
	public String getStatus() { return status; }
	/**
	 * Metodo per impostare lo stato del regolatore di livello.
	 * @param status lo stato del regolatore di livello
	 */
	public void setStatus(String status) { this.status = status; }
	
	/**
	 * Metodo per ottenere l'acquario che possiede il regolatore di livello.
	 * @return l'acquario che possiede il regolatore di livello
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario che possiede il regolatore di livello.
	 * @param acquarium l'acquario che possiede il regolatore di livello
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
