package com.myacquarium.agent.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.agent.db.sc.Device;

/**
 * Classe persistente dell'entita' Illuminazione rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class Illuminazione extends Device {
	
	/** Stato del dispositivo di illuminazione (D illuminazione diurna, N illuminazione notturna, OFF spento). */
	@Column(columnDefinition = "varchar(255) default 'OFF'")
	private String status = "OFF";
	
	/** L'acquario che possiede il dispositivo di illuminazione. */
	@OneToOne(mappedBy = "illuminazione")
    private Acquarium acquarium;
	
	/**
	 * Metodo per ottenere lo stato del dispositivo di illuminazione.
	 * @return lo stato del dispositivo di illuminazione
	 */
	public String getStatus() { return status; }
	/**
	 * Metodo per impostare lo stato del dispositivo di illuminazione.
	 * @param status lo stato del dispositivo di illuminazione
	 */
	public void setStatus(String status) { this.status = status; }
	
	/**
	 * Metodo per ottenere l'acquario che possiede il dispositivo di illuminazione.
	 * @return l'acquario che possiede il dispositivo di illuminazione
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario che possiede il dispositivo di illuminazione.
	 * @param acquarium l'acquario che possiede il dispositivo di illuminazione
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
