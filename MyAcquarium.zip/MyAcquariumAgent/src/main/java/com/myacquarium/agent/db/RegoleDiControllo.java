package com.myacquarium.agent.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.agent.db.sc.EntityWithId;

/**
 * Classe persistente dell'entita' RegoleDiControllo rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class RegoleDiControllo extends EntityWithId {
	
	/** Orario in cui attivare il distributore di cibo per dare il primo pasto ai pesci (orario variabile da 00:00 a 11:59, predefinito 10:00). */
	@Column
	private java.time.LocalTime ciboTime1 = java.time.LocalTime.of(10, 00);
	
	/** Orario in cui attivare il distributore di cibo per dare il secondo pasto ai pesci (orario variabile da 12:00 a 23:59, predefinito 20:00). */
	@Column
	private java.time.LocalTime ciboTime2 = java.time.LocalTime.of(20, 00);
	
	/** Orario in cui attivare l'illuminazione diurna (orario variabile da 00:00 a 11:59, predefinito 09:00). */
	@Column
	private java.time.LocalTime inizioLuceDiurna = java.time.LocalTime.of(9, 00);
	
	/** Orario in cui attivare l'illuminazione notturna (orario variabile da 12:00 a 23:59, predefinito 21:00). */
	@Column
	private java.time.LocalTime inizioLuceNotturna = java.time.LocalTime.of(21, 00);
	
	// --------------------------------------------------------------------------
	
	/**
	 * Valore minimo di temperatura
	 * (termoregolatore in riscaldamento se la temperatura attuale e' minore del valore minTemp,
	 * si spegnera' quando la temperatura attuale avra' raggiunto il valore minTemp).
	 * */
	@Column
	private Float minTemp;
	
	/**
	 * Valore massimo di temperatura
	 * (termoregolatore in raffreddamento se la temperatura attuale e' maggiore del valore maxTemp,
	 * si spegnera' quando la temperatura attuale avra' raggiunto il valore maxTemp).
	 */
	@Column
	private Float maxTemp;
	
	// --------------------------------------------------------------------------
	
	/**
	 * Valore minimo di livello dell'acqua
	 * (regolatore di livello in aggiunta se il livello dell'acqua attuale e' minore del valore minWaterLevel,
	 * si spegnera' quando il livello dell'acqua attuale avra' raggiunto il valore minWaterLevel).
	 */
	@Column
	private Float minWaterLevel;
	
	/**
	 * Valore massimo di livello dell'acqua
	 * (regolatore di livello in rimozione se il livello dell'acqua attuale e' maggiore del valore maxWaterLevel,
	 * si spegnera' quando il livello dell'acqua attuale avra' raggiunto il valore maxWaterLevel).
	 */
	@Column
	private Float maxWaterLevel;

	// --------------------------------------------------------------------------
	
	/**
	 * Valore minimo di calcio
	 * (reattore di calcio attivo a fornire calcio se il valore di calcio attuale e' minore del valore minCa,
	 * si spegnera' quando il valore di calcio attuale avra' raggiunto il valore massimo di calcio maxCa).
	 */
	@Column
	private Float minCa;
	
	/**
	 * Valore massimo di calcio
	 * (reattore di calcio spento al superamento di tale valore).
	 */
	@Column
	private Float maxCa;
	
	// --------------------------------------------------------------------------
	
	/**
	 * Valore minimo di anidride carbonica
	 * (impianto di anidride carbonica attivo a fornire anidride carbonica se il valore di anidride carbonica attuale e' minore del valore minCO2,
	 * si spegnera' quando il valore di anidride carbonica attuale avra' raggiunto il valore massimo di anidride carbonica maxCO2).
	 */
	@Column
	private Float minCO2;
	
	/**
	 * Valore massimo di anidride carbonica
	 * (impianto di anidride carbonica spento al superamento di tale valore).
	 */
	@Column
	private Float maxCO2;
	
	// --------------------------------------------------------------------------
	
	/**
	 * Valore minimo di nitrati
	 * (filtro di nitrati spento al superamento (valore inferiore) di tale valore).
	 */
	@Column
	private Float minNO3;
	
	/**
	 * Valore massimo di nitrati
	 * (filtro di nitrati attivo a rimuovere nitrati se il valore di nitrati attuale e' maggiore del valore maxNO3,
	 * si spegnera' quando il valore di nitrati attuale avra' raggiunto il valore minimo di nitrati minNO3).
	 */
	@Column
	private Float maxNO3;
	
	// --------------------------------------------------------------------------
	
	/**
	 * Valore minimo di fosfati
	 * (filtro di fosfati spento al superamento (valore inferiore) di tale valore).
	 */
	@Column
	private Float minPO4;
	
	/**
	 * Valore massimo di fosfati
	 * (filtro di fosfati attivo a rimuovere fosfati se il valore di fosfati attuale e' maggiore del valore maxPO4,
	 * si spegnera' quando il valore di fosfati attuale avra' raggiunto il valore minimo di fosfati minPO4).
	 */
	@Column
	private Float maxPO4;
	
	// --------------------------------------------------------------------------
	
	/**
	 * Valore minimo di silicati
	 * (filtro di silicati spento al superamento (valore inferiore) di tale valore).
	 */
	@Column
	private Float minSiO4;
	
	/**
	 * Valore massimo di silicati
	 * (filtro di silicati attivo a rimuovere silicati se il valore di silicati attuale e' maggiore del valore maxSiO4,
	 * si spegnera' quando il valore di silicati attuale avra' raggiunto il valore minimo di silicati minSiO4).
	 */
	@Column
	private Float maxSiO4;
	
	// --------------------------------------------------------------------------
	
	/** L'acquario a cui fan riferimento le regole di controllo. */
	@OneToOne(mappedBy = "regoleDiControllo")
    private Acquarium acquarium;
	
	// --------------------------------------------------------------------------
	
	/**
	 * Metodo per ottenere l'orario in cui attivare il distributore di cibo per dare il primo pasto ai pesci.
	 * @return l'orario in cui attivare il distributore di cibo
	 */
	public java.time.LocalTime getCiboTime1() { return ciboTime1; }
	/**
	 * Metodo per impostare l'orario in cui attivare il distributore di cibo per dare il primo pasto ai pesci,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param ciboTime1 orario in cui attivare il distributore di cibo
	 */
	public void setCiboTime1(java.time.LocalTime ciboTime1) { this.ciboTime1 = ciboTime1; }
	
	/**
	 * Metodo per ottenere l'orario in cui attivare il distributore di cibo per dare il secondo pasto ai pesci.
	 * @return l'orario in cui attivare il distributore di cibo
	 */
	public java.time.LocalTime getCiboTime2() { return ciboTime2; }
	/**
	 * Metodo per impostare l'orario in cui attivare il distributore di cibo per dare il secondo pasto ai pesci,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param ciboTime2 orario in cui attivare il distributore di cibo
	 */
	public void setCiboTime2(java.time.LocalTime ciboTime2) { this.ciboTime2 = ciboTime2; }
	
	/**
	 * Metodo per ottenere l'orario in cui attivare l'illuminazione diurna.
	 * @return l'orario in cui attivare l'illuminazione diurna
	 */
	public java.time.LocalTime getInizioLuceDiurna() { return inizioLuceDiurna; }
	/**
	 * Metodo per impostare l'orario in cui attivare l'illuminazione diurna,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param inizioLuceDiurna orario in cui attivare l'illuminazione diurna
	 */
	public void setInizioLuceDiurna(java.time.LocalTime inizioLuceDiurna) { this.inizioLuceDiurna = inizioLuceDiurna; }
	
	/**
	 * Metodo per ottenere l'orario in cui attivare l'illuminazione notturna.
	 * @return l'orario in cui attivare l'illuminazione notturna.
	 */
	public java.time.LocalTime getInizioLuceNotturna() { return inizioLuceNotturna; }
	/**
	 * Metodo per impostare l'orario in cui attivare l'illuminazione notturna,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param inizioLuceNotturna orario in cui attivare l'illuminazione notturna
	 */
	public void setInizioLuceNotturna(java.time.LocalTime inizioLuceNotturna) { this.inizioLuceNotturna = inizioLuceNotturna; }

	/**
	 * Metodo per ottenere il valore minimo di temperatura.
	 * @return il valore minimo di temperatura
	 */
	public Float getMinTemp() { return minTemp; }
	/**
	 * Metodo per impostare il valore minimo di temperatura,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param minTemp il valore minimo di temperatura
	 */
	public void setMinTemp(Float minTemp) { this.minTemp = minTemp; }

	/**
	 * Metodo per ottenere il valore massimo di temperatura.
	 * @return il valore massimo di temperatura
	 */
	public Float getMaxTemp() { return maxTemp; }
	/**
	 * Metodo per impostare il valore massimo di temperatura,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param maxTemp il valore massimo di temperatura
	 */
	public void setMaxTemp(Float maxTemp) { this.maxTemp = maxTemp; }

	/**
	 * Metodo per ottenere il valore minimo di livello dell'acqua.
	 * @return il valore minimo di livello dell'acqua
	 */
	public Float getMinWaterLevel() { return minWaterLevel; }
	/**
	 * Metodo per impostare il valore minimo di livello dell'acqua,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param minWaterLevel il valore minimo di livello dell'acqua
	 */
	public void setMinWaterLevel(Float minWaterLevel) { this.minWaterLevel = minWaterLevel; }

	/**
	 * Metodo per ottenere il valore massimo di livello dell'acqua.
	 * @return il valore massimo di livello dell'acqua
	 */
	public Float getMaxWaterLevel() { return maxWaterLevel; }
	/**
	 * Metodo per impostare il valore massimo di livello dell'acqua,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param maxWaterLevel il valore massimo di livello dell'acqua
	 */
	public void setMaxWaterLevel(Float maxWaterLevel) { this.maxWaterLevel = maxWaterLevel; }

	/**
	 * Metodo per ottenere il valore minimo di calcio.
	 * @return il valore minimo di calcio
	 */
	public Float getMinCa() { return minCa; }
	/**
	 * Metodo per impostare il valore minimo di calcio,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param minCa il valore minimo di calcio
	 */
	public void setMinCa(Float minCa) { this.minCa = minCa; }

	/**
	 * Metodo per ottenere il valore massimo di calcio.
	 * @return il valore massimo di calcio
	 */
	public Float getMaxCa() { return maxCa; }
	/**
	 * Metodo per impostare il valore massimo di calcio,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param maxCa il valore massimo di calcio
	 */
	public void setMaxCa(Float maxCa) { this.maxCa = maxCa; }

	/**
	 * Metodo per ottenere il valore minimo di anidride carbonica.
	 * @return il valore minimo di anidride carbonica
	 */
	public Float getMinCO2() { return minCO2; }
	/**
	 * Metodo per impostare il valore minimo di anidride carbonica,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param minCO2 il valore minimo di anidride carbonica
	 */
	public void setMinCO2(Float minCO2) { this.minCO2 = minCO2; }

	/**
	 * Metodo per ottenere il valore massimo di anidride carbonica.
	 * @return il valore massimo di anidride carbonica
	 */
	public Float getMaxCO2() { return maxCO2; }
	/**
	 * Metodo per impostare il valore massimo di anidride carbonica,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param maxCO2 il valore massimo di anidride carbonica
	 */
	public void setMaxCO2(Float maxCO2) { this.maxCO2 = maxCO2; }

	/**
	 * Metodo per ottenere il valore minimo di nitrati.
	 * @return il valore minimo di nitrati
	 */
	public Float getMinNO3() { return minNO3; }
	/**
	 * Metodo per impostare il valore minimo di nitrati,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param minNO3 il valore minimo di nitrati
	 */
	public void setMinNO3(Float minNO3) { this.minNO3 = minNO3; }
	
	/**
	 * Metodo per ottenere il valore massimo di nitrati.
	 * @return il valore massimo di nitrati
	 */
	public Float getMaxNO3() { return maxNO3; }
	/**
	 * Metodo per impostare il valore massimo di nitrati,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param maxNO3 il valore massimo di nitrati
	 */
	public void setMaxNO3(Float maxNO3) { this.maxNO3 = maxNO3; }

	/**
	 * Metodo per ottenere il valore minimo di fosfati.
	 * @return il valore minimo di fosfati
	 */
	public Float getMinPO4() { return minPO4; }
	/**
	 * Metodo per impostare il valore minimo di fosfati,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param minPO4 il valore minimo di fosfati
	 */
	public void setMinPO4(Float minPO4) { this.minPO4 = minPO4; }
	
	/**
	 * Metodo per ottenere il valore massimo di fosfati.
	 * @return il valore minimo di fosfati
	 */
	public Float getMaxPO4() { return maxPO4; }
	/**
	 * Metodo per impostare il valore massimo di fosfati,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param maxPO4 il valore minimo di fosfati
	 */
	public void setMaxPO4(Float maxPO4) { this.maxPO4 = maxPO4; }

	/**
	 * Metodo per ottenere il valore minimo di silicati.
	 * @return il valore minimo di silicati
	 */
	public Float getMinSiO4() { return minSiO4; }
	/**
	 * Metodo per impostare il valore minimo di silicati,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param minSiO4 il valore minimo di silicati
	 */
	public void setMinSiO4(Float minSiO4) { this.minSiO4 = minSiO4; }
	
	/**
	 * Metodo per ottenere il valore massimo di silicati.
	 * @return il valore massimo di silicati
	 */
	public Float getMaxSiO4() { return maxSiO4; }
	/**
	 * Metodo per impostare il valore massimo di silicati,
	 * utilizzato in fase di impostazione delle regole di controllo predefinite durante la creazione dell'acquario o in successive modifiche a questa regola.
	 * @param maxSiO4 il valore massimo di silicati
	 */
	public void setMaxSiO4(Float maxSiO4) { this.maxSiO4 = maxSiO4; }
	
	/**
	 * Metodo per ottenere l'acquario a cui fan riferimento le regole di controllo.
	 * @return l'acquario a cui fan riferimento le regole di controllo
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario a cui fan riferimento le regole di controllo.
	 * @param acquarium l'acquario a cui fan riferimento le regole di controllo
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
	/** Metodo per impostare le regole di controllo predefinite per l'acquario dolce */
	public void setDefaultDolce() {
		this.setMinTemp((float)20); this.setMaxTemp((float)24);
		this.setMinWaterLevel((float)97); this.setMaxWaterLevel((float)99);
		this.setMinCa((float)400); this.setMaxCa((float)450);
		this.setMinCO2((float)20); this.setMaxCO2((float)40);
		this.setMinNO3((float)10); this.setMaxNO3((float)60);
		this.setMinPO4((float)0.02); this.setMaxPO4((float)0.20);
		this.setMinSiO4((float)0); this.setMaxSiO4((float)0.30);
	}
	
	/** Metodo per impostare le regole di controllo predefinite per l'acquario marino */
	public void setDefaultMarino() {
		this.setMinTemp((float)25); this.setMaxTemp((float)26);
		this.setMinWaterLevel((float)97); this.setMaxWaterLevel((float)99);
		this.setMinCa((float)400); this.setMaxCa((float)450);
		this.setMinCO2((float)20); this.setMaxCO2((float)40);
		this.setMinNO3((float)10); this.setMaxNO3((float)30);
		this.setMinPO4((float)0.02); this.setMaxPO4((float)0.10);
		this.setMinSiO4((float)0); this.setMaxSiO4((float)0.30);
	}
	
}
