package com.myacquarium.agent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe utilizzata per eseguire il bootstrap e lanciare l'applicazione Spring dal metodo main di Java.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@SpringBootApplication
public class MyAcquariumAgent {

	/**
	 * Metodo principale per il lancio dell'applicazione Spring.
	 * @param args argomenti passati come parametro all'applicazione
	 */
	public static void main(String[] args) {
		SpringApplication.run(MyAcquariumAgent.class, args);
	}

}
