package com.myacquarium.agent.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.agent.db.ReattoreDiCalcio;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo ReattoreDiCalcio
 * che sara' implementata automaticamente da Spring in un Bean chiamato reattoreDiCalcioRepository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface ReattoreDiCalcioRepository extends CrudRepository<ReattoreDiCalcio, UUID> {}
