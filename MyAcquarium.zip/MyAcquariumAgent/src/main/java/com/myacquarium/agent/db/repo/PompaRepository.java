package com.myacquarium.agent.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.agent.db.Pompa;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo Pompa
 * che sara' implementata automaticamente da Spring in un Bean chiamato pompaRepository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface PompaRepository extends CrudRepository<Pompa, UUID> {}
