package com.myacquarium.agent.db.repo;

import java.util.List;
import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.agent.db.Acquarium;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo Acquarium
 * che sara' implementata automaticamente da Spring in un Bean chiamato acquariumRepository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

public interface AcquariumRepository extends CrudRepository<Acquarium, UUID> {
	
	/**
	 * Metodo per cercare gli acquari dato l'username dell'utente.
	 * @param username username dell'utente di cui si vogliono cercare gli acquari
	 * @return collezione di acquari che soddisfano la ricerca
	 */
	List<Acquarium> findByUtente(String username);
	 
}
