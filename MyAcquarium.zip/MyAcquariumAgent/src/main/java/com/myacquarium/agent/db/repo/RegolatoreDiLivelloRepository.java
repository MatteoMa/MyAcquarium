package com.myacquarium.agent.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.agent.db.RegolatoreDiLivello;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo RegolatoreDiLivello
 * che sara' implementata automaticamente da Spring in un Bean chiamato regolatoreDiLivelloRepository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface RegolatoreDiLivelloRepository extends CrudRepository<RegolatoreDiLivello, UUID> {}
