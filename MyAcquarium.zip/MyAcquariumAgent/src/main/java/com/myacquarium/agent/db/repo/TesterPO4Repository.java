package com.myacquarium.agent.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.agent.db.TesterPO4;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo TesterPO4
 * che sara' implementata automaticamente da Spring in un Bean chiamato testerPO4Repository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface TesterPO4Repository extends CrudRepository<TesterPO4, UUID> {}
