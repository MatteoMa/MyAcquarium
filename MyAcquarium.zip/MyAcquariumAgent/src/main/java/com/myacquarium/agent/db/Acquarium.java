package com.myacquarium.agent.db;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import com.myacquarium.agent.db.sc.EntityWithId;

/**
 * Classe persistente dell'entita' Acquario rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class Acquarium extends EntityWithId {
	
	/** L'username dell'utente che possiede l'acquario (obbligatorio). */
	@Column
	@NotNull
	private String utente;
	
	/** Il nome dell'acquario (obbligatorio). */
	@Column
	@NotNull
	private String nome;

	/** Le varie tipologie di pesci nell'acquario (facoltativo). */
	@Column
	@NotNull
	private String pesci = "";
	
	/** Il tipo di acquario (dolce/marino, obbligatorio). */
	@Column
	@NotNull
	private String tipo;
	
	/** Classe rappresentante il distributore di cibo (obbligatorio). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private DistributoreDiCibo distributoreDiCibo;
	
	/** Classe rappresentante il dispositivo di illuminazione (obbligatorio). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private Illuminazione illuminazione;
	
	/** Classe rappresentante la pompa (obbligatorio). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private Pompa pompa;
	
	/** Classe rappresentante il termoregolatore (facoltativo). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private Termoregolatore termoregolatore;
	
	/** Classe rappresentante il regolatore di livello (facoltativo). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private RegolatoreDiLivello regolatoreDiLivello;
	
	/** Classe rappresentante il tester di calcio (facoltativo). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private TesterCa testerCa;
	
	/** Classe rappresentante il tester di anidride carbonica (facoltativo). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private TesterCO2 testerCO2;
	
	/** Classe rappresentante il tester di pH (facoltativo). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private TesterpH testerpH;
	
	/** Classe rappresentante il tester di nitrati (facoltativo). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private TesterNO3 testerNO3;
	
	/** Classe rappresentante il tester di fosfati (facoltativo). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private TesterPO4 testerPO4;
	
	/** Classe rappresentante il tester di silicati (facoltativo). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private TesterSiO4 testerSiO4;
	
	/** Classe rappresentante il regolatore di calcio (facoltativo, disponibile in presenza di un tester di calcio). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private ReattoreDiCalcio reattoreDiCalcio;
	
	/** Classe rappresentante l'impianto di anidride carbonica (facoltativo, disponibile in presenza di un tester di anidride carbonica). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private ImpiantoCO2 impiantoCO2;
	
	/** Classe rappresentante il filtro di nitrati (facoltativo, disponibile in presenza di un tester di nitrati). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private FiltroNO3 filtroNO3;
	
	/** Classe rappresentante il filtro di fosfati (facoltativo, disponibile in presenza di un tester di fosfati). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private FiltroPO4 filtroPO4;
	
	/** Classe rappresentante il filtro di silicati (facoltativo, disponibile in presenza di un tester di silicati). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private FiltroSiO4 filtroSiO4;
	
	/** Classe rappresentante lo schiumatoio per la purificazione dell'acqua da composti nocivi (facoltativo). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private Schiumatoio schiumatoio;
	
	/** Classe rappresentante il reattore ad alghe per la purificazione dell'acqua da composti nocivi (facoltativo). */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private ReattoreAdAlghe reattoreAdAlghe;
	
	/** Classe rappresentante le regole di controllo. */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private RegoleDiControllo regoleDiControllo;
	
	/** Classe rappresentante i dati ricevuti dai dispositivi. */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private DatiSensoriRicevuti datiSensoriRicevuti;
	
	/** Classe rappresentante il monitoraggio ricevuto dal servizio di monitoraggio. */
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(referencedColumnName = "id")
	private MonitoraggioRicevuto monitoraggioRicevuto;
	
	/** Collezione di classe rappresentante gli avvisi ricevuti dai dispositivi. */
	@OneToMany(fetch = FetchType.EAGER, mappedBy="acquarium", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Avviso> avvisi = new ArrayList<>();
	
	/**
	 * Metodo per ottenere l'username dell'utente che possiede l'acquario.
	 * @return l'username dell'utente che possiede l'acquario
	 */
	public String getUtente() { return utente; }
	/**
	 * Metodo per impostare l'username dell'utente che ha creato l'acquario.
	 * @param utente l'username dell'utente
	 */
	public void setUtente(String utente) { this.utente = utente; }
	
	/**
	 * Metodo per ottenere il nome dell'acquario.
	 * @return il nome dell'acquario
	 */
	public String getNome() { return nome; }
	/**
	 * Metodo per impostare il nome dell'acquario, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param nome il nome dell'acquario
	 */
	public void setNome(String nome) { this.nome = nome; }
	
	/**
	 * Metodo per ottenere le varie tipologie di pesci nell'acquario.
	 * @return stringa rappresentante le varie tipologie di pesci nell'acquario
	 */
	public String getPesci() { return pesci; }
	/**
	 * Metodo per impostare le varie tipologie di pesci nell'acquario, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param pesci stringa rappresentante le varie tipologie di pesci nell'acquario
	 */
	public void setPesci(String pesci) { this.pesci = pesci; }
	
	/**
	 * Metodo per ottenere il tipo di acquario.
	 * @return il tipo di acquario
	 */
	public String getTipo() { return tipo; }
	/**
	 * Metodo per impostare il tipo di acquario, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param tipo il tipo di acquario (dolce/marino)
	 */
	public void setTipo(String tipo) { this.tipo = tipo; }
	
	/**
	 * Metodo per ottenere il distributore di cibo.
	 * @return il distributore di cibo
	 */
	public DistributoreDiCibo getDistributoreDiCibo() { return distributoreDiCibo; }
	/**
	 * Metodo per impostare il distributore di cibo, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param distributoreDiCibo il distributore di cibo
	 */
	public void setDistributoreDiCibo(DistributoreDiCibo distributoreDiCibo) { this.distributoreDiCibo = distributoreDiCibo; }
	
	/**
	 * Metodo per ottenere il dispositivo di illuminazione.
	 * @return il dispositivo di illuminazione
	 */
	public Illuminazione getIlluminazione() { return illuminazione; }
	/**
	 * Metodo per impostare il dispositivo di illuminazione, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param illuminazione il dispositivo di illuminazione
	 */
	public void setIlluminazione(Illuminazione illuminazione) { this.illuminazione = illuminazione; }
	
	/**
	 * Metodo per ottenere la pompa.
	 * @return la pompa
	 */
	public Pompa getPompa() { return pompa; }
	/**
	 * Metodo per impostare la pompa, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param pompa la pompa
	 */
	public void setPompa(Pompa pompa) { this.pompa = pompa; }
	
	/**
	 * Metodo per ottenere il termoregolatore.
	 * @return il termoregolatore
	 */
	public Termoregolatore getTermoregolatore() { return termoregolatore; }
	/**
	 * Metodo per impostare il termoregolatore, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param termoregolatore il termoregolatore
	 */
	public void setTermoregolatore(Termoregolatore termoregolatore) { this.termoregolatore = termoregolatore; }
	
	/**
	 * Metodo per ottenere il regolatore di livello.
	 * @return il regolatore di livello
	 */
	public RegolatoreDiLivello getRegolatoreDiLivello() { return regolatoreDiLivello; }
	/**
	 * Metodo per impostare il regolatore di livello, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param regolatoreDiLivello il regolatore di livello
	 */
	public void setRegolatoreDiLivello(RegolatoreDiLivello regolatoreDiLivello) { this.regolatoreDiLivello = regolatoreDiLivello; }
	
	/**
	 * Metodo per ottenere il tester di calcio.
	 * @return il tester di calcio
	 */
	public TesterCa getTesterCa() { return testerCa; }
	/**
	 * Metodo per impostare il tester di calcio, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param testerCa il tester di calcio
	 */
	public void setTesterCa(TesterCa testerCa) { this.testerCa = testerCa; }
	
	/**
	 * Metodo per ottenere il tester di anidride carbonica.
	 * @return il tester di anidride carbonica
	 */
	public TesterCO2 getTesterCO2() { return testerCO2; }
	/**
	 * Metodo per impostare il tester di anidride carbonica, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param testerCO2 il tester di anidride carbonica
	 */
	public void setTesterCO2(TesterCO2 testerCO2) { this.testerCO2 = testerCO2; }
	
	/**
	 * Metodo per ottenere il tester di pH.
	 * @return il tester di pH
	 */
	public TesterpH getTesterpH() { return testerpH; }
	/**
	 * Metodo per impostare il tester di pH, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param testerpH il tester di pH
	 */
	public void setTesterpH(TesterpH testerpH) { this.testerpH = testerpH; }
	
	/**
	 * Metodo per ottenere il tester di nitrati.
	 * @return il tester di nitrati
	 */
	public TesterNO3 getTesterNO3() { return testerNO3; }
	/**
	 * Metodo per impostare il tester di nitrati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param testerNO3 il tester di nitrati
	 */
	public void setTesterNO3(TesterNO3 testerNO3) { this.testerNO3 = testerNO3; }
	
	/**
	 * Metodo per ottenere il tester di fosfati.
	 * @return il tester di fosfati
	 */
	public TesterPO4 getTesterPO4() { return testerPO4; }
	/**
	 * Metodo per impostare il tester di fosfati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param testerPO4 il tester di fosfati
	 */
	public void setTesterPO4(TesterPO4 testerPO4) { this.testerPO4 = testerPO4; }
	
	/**
	 * Metodo per ottenere il tester di silicati.
	 * @return il tester di silicati
	 */
	public TesterSiO4 getTesterSiO4() { return testerSiO4; }
	/**
	 * Metodo per impostare il tester di silicati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param testerSiO4 il tester di silicati
	 */
	public void setTesterSiO4(TesterSiO4 testerSiO4) { this.testerSiO4 = testerSiO4; }
	
	/**
	 * Metodo per ottenere il regolatore di calcio.
	 * @return il regolatore di calcio
	 */
	public ReattoreDiCalcio getReattoreDiCalcio() { return reattoreDiCalcio; }
	/**
	 * Metodo per impostare il regolatore di calcio, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param reattoreDiCalcio il regolatore di calcio
	 */
	public void setReattoreDiCalcio(ReattoreDiCalcio reattoreDiCalcio) { this.reattoreDiCalcio = reattoreDiCalcio; }
	
	/**
	 * Metodo per ottenere l'impianto di anidride carbonica.
	 * @return l'impianto di anidride carbonica
	 */
	public ImpiantoCO2 getImpiantoCO2() { return impiantoCO2; }
	/**
	 * Metodo per impostare l'impianto di anidride carbonica, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param impiantoCO2 l'impianto di anidride carbonica
	 */
	public void setImpiantoCO2(ImpiantoCO2 impiantoCO2) { this.impiantoCO2 = impiantoCO2; }
	
	/**
	 * Metodo per ottenere il filtro di nitrati.
	 * @return il codice del filtro di nitrati
	 */
	public FiltroNO3 getFiltroNO3() { return filtroNO3; }
	/**
	 * Metodo per impostare il filtro di nitrati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param filtroNO3 il filtro di nitrati
	 */
	public void setFiltroNO3(FiltroNO3 filtroNO3) { this.filtroNO3 = filtroNO3; }
	
	/**
	 * Metodo per ottenere il filtro di fosfati.
	 * @return il filtro di fosfati
	 */
	public FiltroPO4 getFiltroPO4() { return filtroPO4; }
	/**
	 * Metodo per impostare il filtro di fosfati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param filtroPO4 il filtro di fosfati
	 */
	public void setFiltroPO4(FiltroPO4 filtroPO4) { this.filtroPO4 = filtroPO4; }
	
	/**
	 * Metodo per ottenere il filtro di silicati.
	 * @return il filtro di silicati
	 */
	public FiltroSiO4 getFiltroSiO4() { return filtroSiO4; }
	/**
	 * Metodo per impostare il filtro di silicati, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param filtroSiO4 il filtro di silicati
	 */
	public void setFiltroSiO4(FiltroSiO4 filtroSiO4) { this.filtroSiO4 = filtroSiO4; }
	
	/**
	 * Metodo per ottenere lo schiumatoio.
	 * @return lo schiumatoio
	 */
	public Schiumatoio getSchiumatoio() { return schiumatoio; }
	/**
	 * Metodo per impostare lo schiumatoio, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param schiumatoio lo schiumatoio
	 */
	public void setSchiumatoio(Schiumatoio schiumatoio) { this.schiumatoio = schiumatoio; }
	
	/**
	 * Metodo per ottenere il reattore ad alghe.
	 * @return il reattore ad alghe
	 */
	public ReattoreAdAlghe getReattoreAdAlghe() { return reattoreAdAlghe; }
	/**
	 * Metodo per impostare il reattore ad alghe, utilizzato in fase di creazione o modifica dell'acquario.
	 * @param reattoreAdAlghe il reattore ad alghe
	 */
	public void setReattoreAdAlghe(ReattoreAdAlghe reattoreAdAlghe) { this.reattoreAdAlghe = reattoreAdAlghe; }
	
	/**
	 * Metodo per ottenere le regole di controllo.
	 * @return le regole di controllo
	 */
	public RegoleDiControllo getRegoleDiControllo() { return regoleDiControllo; }
	/**
	 * Metodo per impostare le regole di controllo, utilizzato in fase di creazione dell'acquario o modifica delle regole di controllo.
	 * @param regoleDiControllo  le regole di controllo
	 */
	public void setRegoleDiControllo(RegoleDiControllo regoleDiControllo) { this.regoleDiControllo = regoleDiControllo; }
	
	/**
	 * Metodo per ottenere i dati ricevuti dai dispositivi.
	 * @return i dati ricevuti dai dispositivi
	 */
	public DatiSensoriRicevuti getDatiSensoriRicevuti() { return datiSensoriRicevuti ; }
	/**
	 * Metodo per impostare i dati ricevuti dai dispositivi.
	 * @param datiSensoriRicevuti i dati ricevuti dai dispositivi
	 */
	public void setDatiSensoriRicevuti (DatiSensoriRicevuti  datiSensoriRicevuti ) { this.datiSensoriRicevuti  = datiSensoriRicevuti ; }
	
	/**
	 * Metodo per ottenere il monitoraggio ricevuto dal servizio di monitoraggio.
	 * @return il monitoraggio ricevuto dal servizio di monitoraggio
	 */
	public MonitoraggioRicevuto getMonitoraggioRicevuto() { return monitoraggioRicevuto ; }
	/**
	 * Metodo per impostare il monitoraggio ricevuto dal servizio di monitoraggio.
	 * @param monitoraggioRicevuto il monitoraggio ricevuto dal servizio di monitoraggio
	 */
	public void setMonitoraggioRicevuto (MonitoraggioRicevuto monitoraggioRicevuto ) { this.monitoraggioRicevuto  = monitoraggioRicevuto ; }
	
	/**
	 * Metodo per ottenere la collezione di avvisi ricevuti dai dispositivi.
	 * @return la collezione di avvisi ricevuti dai dispositivi
	 */
	public List<Avviso> getAvvisi() { return avvisi; }
	/**
	 * Metodo per impostare la collezione di avvisi ricevuti dai dispositivi.
	 * @param avvisi la collezione di avvisi ricevuti dai dispositivi
	 */
	public void setAvvisi(List<Avviso> avvisi) { this.avvisi = avvisi; }
	
	/**
	 * Metodo per aggiungere un avviso alla collezione di avvisi
	 * @param avviso l'avviso da aggiungere
	 */
    public void addAvviso(Avviso avviso) {
        avvisi.add(avviso);
        avviso.setAcquarium(this);
    }
 
	/**
	 * Metodo per rimuovere un avviso alla collezione di avvisi
	 * @param avviso l'avviso da rimuovere
	 */
    public void removeAvviso(Avviso avviso) {
        avvisi.remove(avviso);
        avviso.setAcquarium(null);
    }

}
