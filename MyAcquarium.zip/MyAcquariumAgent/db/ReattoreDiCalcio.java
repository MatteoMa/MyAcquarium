package com.myacquarium.app.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.app.db.sc.Device;

/**
 * Classe persistente dell'entita' ReattoreDiCalcio rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class ReattoreDiCalcio extends Device {
	
	/** Stato del reattore di calcio (ON acceso, OFF spento). */
	@Column(columnDefinition = "varchar(255) default 'OFF'")
	private String status = "OFF";
	
	/** L'acquario che possiede il reattore di calcio. */
	@OneToOne(mappedBy = "reattoreDiCalcio")
    private Acquarium acquarium;
	
	/**
	 * Metodo per ottenere lo stato del reattore di calcio.
	 * @return lo stato del reattore di calcio
	 */
	public String getStatus() { return status; }
	/**
	 * Metodo per impostare lo stato del reattore di calcio.
	 * @param status lo stato del reattore di calcio
	 */
	public void setStatus(String status) { this.status = status; }
	
	/**
	 * Metodo per ottenere l'acquario che possiede il reattore di calcio.
	 * @return l'acquario che possiede il reattore di calcio
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario che possiede il reattore di calcio.
	 * @param acquarium l'acquario che possiede il reattore di calcio
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}

