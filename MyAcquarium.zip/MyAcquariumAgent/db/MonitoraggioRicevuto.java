package com.myacquarium.app.db;

import java.util.List;
import java.util.ArrayList;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

import com.myacquarium.app.db.sc.EntityWithId;

/**
 * Classe persistente dell'entita' MonitoraggioRicevuto rappresentante l'oggetto della base dati utilizzata per mappare la tabella dell'oggetto nel database.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */

@Entity
public class MonitoraggioRicevuto extends EntityWithId {
	
	/** Collezione di valori di temperatura ricevuti dal sistema di monitoraggio. */
	@ElementCollection
	private List<Float> temperature = new ArrayList<Float>();
	
	/** Collezione di valori di livello dell'acqua ricevuti dal sistema di monitoraggio. */
	@ElementCollection
	private List<Float> waterLevel = new ArrayList<Float>();
	
	/** Collezione di valori di calcio ricevuti dal sistema di monitoraggio. */
	@ElementCollection
	private List<Float> ca = new ArrayList<Float>();
	
	/** Collezione di valori di anidride carbonica ricevuti dal sistema di monitoraggio. */
	@ElementCollection
	private List<Float> co2 = new ArrayList<Float>();
	
	/** Collezione di valori di pH ricevuti dal sistema di monitoraggio. */
	@ElementCollection
	private List<Float> ph = new ArrayList<Float>();
	
	/** Collezione di valori di nitrati ricevuti dal sistema di monitoraggio. */
	@ElementCollection
	private List<Float> no3 = new ArrayList<Float>();
	
	/** Collezione di valori di fosfati ricevuti dal sistema di monitoraggio. */
	@ElementCollection
	private List<Float> po4 = new ArrayList<Float>();
	
	/** Collezione di valori di silicati ricevuti dal sistema di monitoraggio. */
	@ElementCollection
	private List<Float> sio4 = new ArrayList<Float>();
	
	/** L'acquario a cui fa riferimento il monitoraggio. */
	@OneToOne(mappedBy = "monitoraggioRicevuto")
    private Acquarium acquarium;
	
	/**
	 * Metodo per ottenere la collezione di valori di temperatura.
	 * @return la collezione di valori di temperatura
	 */
	public List<Float> getTemperature() { return temperature; }
	/**
	 * Metodo per impostare la collezione di valori di temperatura.
	 * @param temperature la collezione di valori di temperatura
	 */
	public void setTemperature(List<Float> temperature) { this.temperature = temperature; }
	
	/**
	 * Metodo per ottenere la collezione di valori di livello dell'acqua.
	 * @return la collezione di valori di livello dell'acqua
	 */
	public List<Float> getWaterLevel() { return waterLevel; }
	/**
	 * Metodo per impostare la collezione di valori di livello dell'acqua.
	 * @param waterLevel la collezione di valori di livello dell'acqua
	 */
	public void setWaterLevel(List<Float> waterLevel) { this.waterLevel = waterLevel; }
	
	/**
	 * Metodo per ottenere la collezione di valori di calcio.
	 * @return la collezione di valori di calcio
	 */
	public List<Float> getCa() { return ca; }
	/**
	 * Metodo per impostare la collezione di valori di calcio.
	 * @param ca la collezione di valori di calcio
	 */
	public void setCa(List<Float> ca) { this.ca = ca; }
	
	/**
	 * Metodo per ottenere la collezione di valori di anidride carbonica.
	 * @return la collezione di valori di anidride carbonica
	 */
	public List<Float> getCo2() { return co2; }
	/**
	 * Metodo per impostare la collezione di valori di anidride carbonica.
	 * @param co2 la collezione di valori di anidride carbonica
	 */
	public void setCo2(List<Float> co2) { this.co2 = co2; }
	
	/**
	 * Metodo per ottenere la collezione di valori di pH.
	 * @return la collezione di valori di pH
	 */
	public List<Float> getPh() { return ph; }
	/**
	 * Metodo per impostare la collezione di valori di pH.
	 * @param ph la collezione di valori di pH
	 */
	public void setPh(List<Float> ph) { this.ph = ph; }
	
	/**
	 * Metodo per ottenere la collezione di valori di nitrati.
	 * @return la collezione di valori di nitrati
	 */
	public List<Float> getNo3() { return no3; }
	/**
	 * Metodo per impostare la collezione di valori di nitrati.
	 * @param no3 la collezione di valori di nitrati
	 */
	public void setNo3(List<Float> no3) { this.no3 = no3; }
	
	/**
	 * Metodo per ottenere la collezione di valori di fosfati.
	 * @return la collezione di valori di fosfati
	 */
	public List<Float> getPo4() { return po4; }
	/**
	 * Metodo per impostare la collezione di valori di fosfati.
	 * @param po4 la collezione di valori di fosfati
	 */
	public void setPo4(List<Float> po4) { this.po4 = po4; }
	
	/**
	 * Metodo per ottenere la collezione di valori di silicati.
	 * @return la collezione di valori di silicati
	 */
	public List<Float> getSio4() { return sio4; }
	/**
	 * Metodo per impostare la collezione di valori di silicati.
	 * @param sio4 la collezione di valori di silicati
	 */
	public void setSio4(List<Float> sio4) { this.sio4 = sio4; }
	
	/**
	 * Metodo per ottenere l'acquario a cui fa riferimento il monitoraggio.
	 * @return l'acquario a cui fa riferimento il monitoraggio
	 */
	public Acquarium getAcquarium() { return acquarium; }
	/**
	 * Metodo per impostare l'acquario a cui fa riferimento il monitoraggio.
	 * @param acquarium l'acquario a cui fa riferimento il monitoraggio
	 */
	public void setAcquarium(Acquarium acquarium) { this.acquarium = acquarium; }
	
}
