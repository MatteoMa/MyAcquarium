package com.myacquarium.app.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.app.db.FiltroPO4;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo FiltroPO4
 * che sara' implementata automaticamente da Spring in un Bean chiamato filtroPO4Repository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface FiltroPO4Repository extends CrudRepository<FiltroPO4, UUID> {}
