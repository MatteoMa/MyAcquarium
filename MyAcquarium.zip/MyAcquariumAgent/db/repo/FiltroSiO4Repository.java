package com.myacquarium.app.db.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.myacquarium.app.db.FiltroSiO4;

/**
 * Interfaccia per operazioni CRUD generiche sul repository di tipo FiltroSiO4
 * che sara' implementata automaticamente da Spring in un Bean chiamato filtroSiO4Repository.
 * 
 * @author Matteo Morando
 * @author Andrea Fornasiero
 */
	
public interface FiltroSiO4Repository extends CrudRepository<FiltroSiO4, UUID> {}
